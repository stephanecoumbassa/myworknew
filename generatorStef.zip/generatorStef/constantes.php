<?php
    $var = ["f_titre", "f_url", "f_photo", "f_categorie", "f_dateposted", "f_topfocus", "f_type"];
    $vars = [
        ["f_titre", "text"],
        ["f_url", "url"],
        ["f_photo", "img"],
        ["f_categorie", "text"],
        ["f_dateposted", "date"],
        ["f_topfocus", "text"],
        ["f_type", "number"]
    ];
    $tablename = 'actualites_focus';
    $name = 'focus';
    $NAME = 'Focus';
    $typerubrique = 41;
    $search = 'f_titre';
    $img = 'logo';
    $dollar = '$';