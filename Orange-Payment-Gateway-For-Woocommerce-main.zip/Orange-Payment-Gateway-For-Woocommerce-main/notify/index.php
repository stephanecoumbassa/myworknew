<h1>Hello</h1>
<?php
// Silence is golden.

