<ul id="menu">
    <li>
        <h1>Nous vous remercions d'avoir choisi le module Orange Money Gateway FAIT PAR ARNAUD</h1>
    </li>
</ul>

<div style="
    background-color: white;
    padding: 20px;
	margin-top: 0;
    margin-right: 20px;
    margin-bottom: 20px;
">
    <h2 style="text-decoration : underline">
        <b>Configuration : </b>
    </h2>
    <p>Pour utiliser le module de paiement Orange Money Gateway, veuillez suivre les étapes de configuration suivantes :</p>
    <ol>
        <li>Remplissez les champs ci-dessous avec vos informations</li>
        <li>Nous vous souhaitons une meilleure vente avec Orange Money Gateway</li>
    </ol>
</div>
<table class='form-table'>
