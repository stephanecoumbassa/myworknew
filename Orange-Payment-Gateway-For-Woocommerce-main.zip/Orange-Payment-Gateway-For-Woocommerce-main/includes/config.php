<?php
/**
 * Created by ABODJE.
 * User: KOUAME PAUL ARNAUD
 * Date: 03/01/2023
 */
class Config
{

    //SANDBOXPARAMETER
        const AUTHORIZATION_HEADER_SAND_BOX_ORANGE_MONEY = "Basic d2pSSm5oM3Zqd0FHVFdZdVllYVNDbWduSDJmc2R4OXk6d29mb2l5MnJLcVFJSFk0NA==";
        const MERCHANT_KEY_SAND_BOX_ORANGE_MONEY = "23860981";
        const URL_ORANGE_WEBPAYMENT_SANDBOX = 'https://api.orange.com/orange-money-webpay/dev/v1/webpayment';
        const URL_ORANGE_TRANSACTION_STATUS_SANDBOX = 'https://api.orange.com/orange-money-webpay/dev/v1/transactionstatus';
        const URL_GETTOKEN_ORANGE = 'https://api.orange.com/oauth/v3/token';

    //PRODPARAMETER
        const AUTHORIZATION_HEADER_PROD_ORANGE_MONEY = "Basic c28wUWszUlRiWFJIU1h1WTY1WENxV0p6TU9FRmF3eWE6TWFyTFBlNHZtTEFnTklqZQ==";
        const URL_ORANGE_WEBPAYMENT_PROD = "https://api.orange.com/orange-money-webpay/dev/v1/webpayment";
        const URL_ORANGE_TRANSACTION_STATUS_PROD = "https://api.orange.com/orange-money-webpay/dev/v1/transactionstatus";
        const MERCHANT_KEY_PROD = "b74d1d6d";

}
