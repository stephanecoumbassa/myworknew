<?php
/*
Plugin Name: WooCommerce Orange Payments Gateway OMCI
Description: PLUGIN PAIEMENT ORANGE WEBPAY.
Version: 1.0.0
Author: ABODJE KOUAME - MARVEL IT
Author URI: https://abodje.com

Copyright: © 2022 MARVEL IT.
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/
if (!defined('ABSPATH')) {
    exit;
}

add_action('plugins_loaded', 'woocommerce_orange_init', 0);

function woocommerce_orange_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    /**
     * Gateway class
     */
    class WC_Orange_Gateway extends WC_Payment_Gateway
    {

        public $params = null;

        public function __construct()
        {
            $this->id = 'orange-money-payment';
            $this->method_title = __('Orange Money', 'orange-money-payment');
            $this->title = __('Payer avec ', 'orange-money-payment');
            $this->icon = plugins_url('images/logo.png', __FILE__);
            $this->has_fields = false;

            $this->init_form_fields();
            $this->init_settings();

            $this->merchantKey = $this->settings['merchantKey'];
            $this->siteurl = $this->settings['siteurl'];
            $this->uri_webpayment = $this->settings['uri_webpayment'];
            $this->uri_transaction = $this->settings['uri_transaction'];
            $this->description = __('Payer vos achats avec Orange Money', 'orange-money-payment');
            $this->notify_url   = add_query_arg( 'wc-api', 'WC_Orange_Gateway', home_url( '/' ) );;

            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, [
                    $this,
                    'process_admin_options',
                ]);
            } else {
                add_action('woocommerce_update_options_payment_gateways', [&$this,
                                                                           'process_admin_options',
                ]);
            }
			//add webhooks woocommerce_api_weldpay_webhook
			//add_action( 'woocommerce_api_weldpay_webhook', array( $this, 'webhook' ) );
      add_action( 'woocommerce_api_weldpay_webhook', array( $this, 'webhook' ) );

        }

        public function init_form_fields()
        {
            $this->form_fields = [
                'enabled' => [
                    'title' => __('Enable/Disable', 'orange-money-payment'),
                    'type' => 'checkbox',
                    'label' => __('Activer le module de paiement Orange Money', 'orange-money-payment'),
                    'default' => '',
                ],
                'siteurl' => [
                    'title' => __('Site URL', 'orange-money-payment'),
                    'type' => 'text',
                    'default' => home_url(),
                ],
                'uri_webpayment' => [
                    'title' => __('URL DE PAIEMENT', 'orange-money-payment'),
                    'type' => 'text',
                    'default' => '',
                ],
                'uri_transaction' => [
                    'title' => __('URL DE TRANSACTION', 'orange-money-payment'),
                    'type' => 'text',
                    'default' => '',
                ],
                'merchantKey' => [
                    'title' => __('MERCHANT KEY', 'orange-money-payment'),
                    'type' => 'password',
                    'default' => '',
                ],
            ];
        }

        /**
         * Admin Panel Options
         */
        public function admin_options()
        {
            include_once 'includes/adminText.php';
            $this->generate_settings_html();
            echo '</table>';
        }

        public function getAccessToken()
        {
            $endPointUrl=Config::URL_GETTOKEN_ORANGE;
            $headerRequest = Config::AUTHORIZATION_HEADER_PROD_ORANGE_MONEY;
            
            $reponse = wp_remote_post($endPointUrl,array(
                'method' => 'POST',
                'timeout' => 45,
                'headers' => array('Authorization'=>$headerRequest),
                'httpversion' => '1.1',
                'body' => array( 'grant_type' => 'client_credentials'),
            ));
            if(is_wp_error($reponse)){
                
               // var_dump($reponse);
                return false;
            }
            $reponse = json_decode($reponse['body']);
           // echo $reponse;
            
            if (isset($reponse->token_type) && $reponse->token_type == 'Bearer') {
                return $reponse->access_token;
            }
            return false;
        }
    
         /**
         * Orange JSON Request 
         * For the Request with JSON Parameter
         * 
         */
        public function orangeJSONRequest($EndPointUrl,$token,$data)
        {
            $reponse = wp_remote_post( $EndPointUrl,array(
                'method' => 'POST',
                'timeout' => 2000,
                'headers' => array('Authorization' =>  "Bearer ".$token, 
                                    'Accept'=> 'application/json',
                                    'Content-Type' => 'application/json'
                                ),
                'httpversion' => '1.1',
                'body' => json_encode($data,true),
            ));
            if(is_wp_error($reponse)){
                echo $EndPointUrl."error";
                //var_dump($reponse);die;
            }
            return $reponse;
        }

        public function includes() {
            require_once("includes/config.php");
        }

        public function process_payment($order_id)
        {
             global $woocommerce;

            $this->includes();
            //Instance the Order
            $order = new WC_Order( $order_id);       
            //OrderId Log For Orange
            $now = new \DateTime();
            $OrangeOrderID = sprintf("%s_%s",$now->format('YmdHis'),$order_id);
            $reference = $order->data['order_key'];
            //Prod Mode
            $merchantKey =  Config::MERCHANT_KEY_PROD;
            $currency = "OUV";
            $PayEndPointUrl = Config::URL_ORANGE_WEBPAYMENT_PROD;
        
            $token = $this->getAccessToken();
						 $file = 'mon_fichierlog.txt';

 
            //Data For the request
            $data = array(
                "order_id" => $OrangeOrderID,
                "merchant_key" => $merchantKey,
                "currency" => $currency,
                "amount" => number_format($order->get_total(), 2, '.', ''),
               // "return_url" => home_url() . '/boutique',
                //"cancel_url" => wc_get_cart_url(),
                //"notif_url" => $this->notify_url,
                "return_url" => home_url(),
				"cancel_url" => wc_get_cart_url(),
				//"notif_url" => $this->notify_url,/faci/wc-api/weldpay_webhook/
				"notif_url" =>   home_url().'/wc-api/weldpay_webhook/?order_id='.$order_id,
                "lang" => "fr",
                "reference" => $reference
            );
			file_put_contents($file, $data);


            WC()->session->set('order_id', $order->id);
            $order->update_status('on-hold', __('Numero transaction :' . $OrangeOrderID . ' - ' . $reference, 'woothemes'));
          //  $woocommerce->cart->empty_cart();

            $reponse = $this->orangeJSONRequest($PayEndPointUrl,$token,$data);


             $reponse = json_decode($reponse['body']);
			 		//	file_put_contents($file, $reponse);

            $url_orange = $reponse->payment_url;
            //Response Processing
            return [
                'result'    => 'success',
                'redirect'  => $url_orange
            ];
           // echo (var_dump($reponse->payment_url));
            }
            public function webhook() {
				global $woocommerce;
						 $file = 'webhook.txt';

                header( 'HTTP/1.1 200 OK' );
                $order_id = isset($_REQUEST['order_id']) ? $_REQUEST['order_id'] : null;
			    $order = new WC_Order( $order_id );
				$res=file_get_contents('php://input') ?? $_REQUEST;
				
			    file_put_contents('./RESPONSEWEB.txt',$res);
				//verification si on recois le retour d'orange 
				$retourorange = json_decode($res,true);
				 if (is_null($order_id)) return;
				if($retourorange['status'] =="SUCCESS"){
					 $order->add_order_note(__('PAIEMENT APPROUVE VIA ORANGE MONEY MP:'.$retourorange['txnid'].'  -- notiftoken '.$retourorange['notif_token'], 'woothemes'),1); 
					 $order->payment_complete();
                     $order->reduce_order_stock();
				} 

              //  $nonce = isset($_REQUEST['nonce']) ? $_REQUEST['nonce'] : null;
               
                //if (is_null($nonce)) return;
               // if (wc_get_order_item_meta($order_id,'ipn_nonce')!=$nonce) return;
               // $order = wc_get_order( $order_id );
               
              }

    }

    /**
     * Add the Gateway to WooCommerce
     *
     */
    function woocommerce_add_orange_gateway($methods)
    {
        $methods[] = 'WC_Orange_Gateway';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_orange_gateway');
	
 
}

register_activation_hook(__FILE__, 'my_plugin_orange_activate');
add_action('admin_init', 'my_plugin_orange_redirect');

function my_plugin_orange_activate()
{
    add_option('my_plugin_do_activation_redirect', true);
}

function my_plugin_orange_redirect()
{
    if (get_option('my_plugin_do_activation_redirect', false)) {
        delete_option('my_plugin_do_activation_redirect');
        wp_redirect(admin_url('admin.php?page=wc-settings&tab=checkout&section=orangemoney'));
    }
}
 