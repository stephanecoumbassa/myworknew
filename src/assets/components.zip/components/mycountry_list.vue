<template>
    <div>
         <div class="form-group">
             <select class="form-control" v-model="country"  v-on:change="handleInput">
                 <option></option>
                 <option v-for="item in countries" :value="item.indicatif">+{{item.indicatif}} {{item.name}}</option>
             </select>
         </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            countries: [],
            country: 225
            // country:  { "id": "1", "name": "COTE D'IVOIRE", "code": "CI", "indicatif": "225", "iso3": "CIV", "nicename": "Cote d'ivoire" }
        }
    },
    model: {
        event: 'blur'
    },
    created: function () {
        this.countries_get();
        this.handleInput();
    },
    methods: {
        handleInput ($event) {
            this.$emit('blur', parseInt(this.country));
        },
        countries_get () {
            getWithParams('/api/get/countries').then((data) => {
                this.countries = data;
                console.log(this.countries);
            });
        }
    }

}
</script>

<style scoped>

</style>
