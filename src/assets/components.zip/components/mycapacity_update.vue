
<template>
    <div>
        <div v-for="item in capacities">
            <form @submit.prevent="capacity_update(item)">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Champs</label>
                            <select v-validate="'required'" class="form-control search-slt" v-model="item.typeid" @input="$emit('blur', capacities)">
                                <option v-for="capacity in capacities_list"
                                        :value="capacity.id"
                                        :key="capacity.id"
                                >{{capacity.name}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Valeur</label>
                            <input v-validate="'required'" class="form-control" type="number" v-model="item.value" />
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Unite</label>
                            <input v-validate="'required'" class="form-control" type="text" v-model="item.unity" />
                        </div>
                    </div>
                    <div class="col-4">
                        <label class="form-text text-dark">Actions</label>
                        <button type="button" class="btn btn-secondary btn-sm" v-on:click="capacity_delete(item)">supprimer</button>
                        <button type="submit" class="btn btn-primary btn-sm">modifier</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            capacities: '',
            country: '',
            capacities_list: ''
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.capacities_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.capacity_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        capacity_get () {
            getWithParams('/api/get/capacities', { id: this.idligne }).then((data) => {
                console.log(data);
                this.capacities = JSON.parse(data.capacities);
                console.log(this.capacities);
            })
        },
        capacities_get () {
            getWithParams('/api/get/capacities_type').then((data) => {
                console.log(data);
                this.capacities_list = data;
            // console.log(this.capacities_list);
            })
        },
        capacity_update (capacity) {
            putWithParams('/api/put/capacities', capacity).then((data) => {
                console.log(data);
            });
        },
        capacity_delete (capacity) {
            console.log(capacity.id);
            deleteWithParams('/api/delete/capacities', { data: { id: capacity.id } }).then((data) => {
                console.log(data);
            });
        }
    }
}
</script>

<style scoped>

</style>
