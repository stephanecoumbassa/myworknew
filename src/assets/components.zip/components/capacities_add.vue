<template>
    <div>
            <div class="row">
                <div class="col-7">
                    <div class="form-group">
                        <label class="form-text text-dark">Champs</label>
                        <input class="form-control" name=""  v-model="speciality"/>
                    </div>
                </div>
                <div class="col-5">
                    <label class="form-text text-dark">.</label>
                    <button type="button" class="btn btn-primary" v-on:click="specialities_create">Creer une specialite</button>
                </div>
            </div>

    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            item: [],
            speciality: ''
        }
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        setSelected (value) {
            // console.log(value);
            this.valeur_json.push(value);
            console.log(this.valeur_json)
        },
        specialities_create () {
            postWithParams('/api/post/specialities_type', { name: this.speciality }).then(data => {
                const res = JSON.stringify(data);
                this.specialities_list = JSON.parse(res);
            // console.log(this.specialities_list);
            });
        }
    }
}
</script>

<style scoped>

</style>
