
<template>
    <div>
        <form>
            <div v-for="item in specialities">
                <div class="row">
                    <!--                {{item}}-->
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Champs</label>
                            <select required class="form-control search-slt" v-model="item.specialityid" @input="$emit('blur', specialities)">
                                <option :value="item.specialityid"
                                        :key="item.specialityid"
                                >{{item.specialityname}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Autocomplete</label>
                            <select required class="form-control search-slt" v-model="item.value_id">
                                <option v-for="auto in JSON.parse(JSON.stringify(item.autocomplete))"
                                        :value="auto.id"
                                        :key="auto.id"
                                >{{auto.name}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <label class="form-text text-dark">Actions</label>
                        <button type="button" class="btn btn-secondary btn-sm" v-on:click="speciality_delete(item)">supprimer</button>
                        <button type="button" class="btn btn-primary btn-sm" v-on:click="speciality_update(item)">modifier</button>
                    </div>
                </div>

            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            speciality: {},
            item: {},
            specialities: {},
            country: '',
            specialities_list: '',
            autocomplete_list: '',
            autocomplete_initiales: ''
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.specialities_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.speciality_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        specialitiesfilter (id) {
            this.autocomplete_list = this.autocomplete_initiales;
            let autos = this.specialities_list.filter((auto) => {
                return auto.id === String(id);
            });
            // console.log(autos);
            this.autocomplete_list = JSON.parse(autos[0].autocomplete);
            console.log(this.autocomplete_list);
        },
        speciality_get () {
            getWithParams('/api/get/specialities', { id: this.idligne }).then((data) => {
                console.log(data);
                this.specialities = JSON.parse(data.specialities);
                console.log(this.specialities_list);
            })
        },
        specialities_get () {
            getWithParams('/api/get/specialities_type').then((data) => {
                console.log(data);
                this.specialities_list = data;
            })
        },
        speciality_update (speciality) {
            putWithParams('/api/put/specialities', speciality).then((data) => {
                console.log(data);
            });
        },
        speciality_delete (speciality) {
            console.log(speciality.id);
            deleteWithParams('/api/delete/specialities', { data: { id: speciality.id } }).then((data) => {
                console.log(data);
            });
        }
    }
}
</script>

<style scoped>

</style>
