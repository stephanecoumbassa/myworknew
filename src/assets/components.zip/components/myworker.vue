<template>
    <div>
        <form>
            <div v-for="q in qui">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Ordre Hierachique</label>
                            <input class="form-control" type="text"  v-model="q.order" @input="$emit('blur', qui)">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Dirigeants</label>
                            <v-select :value="q" @input="setSelected(q)" required label="fullname" v-model="q.qui_id" :options="autocomplete_list" />
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" v-on:click="qui_delete">-</button>
            <button type="button" class="btn btn-primary btn-sm" v-on:click="qui_add">+</button>
            <button type="button" class="btn btn-primary btn-sm" v-on:click="worker_add()">Ajouter</button>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            autocomplete_list: [],
            autocomplete_initiales: '',
            count: 0,
            // qui: [{'qui_id': {'id': null}, 'order': null}],
            qui: [],
            qui2: [],
            qui_list: '',
            val: ''
        }
    },
    created: function () {
        this.qui_get();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
            // this.worker_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        qui_add () {
            this.qui.push({ 'qui_id': { 'id': null }, 'order': null });
            console.log(this.qui);
        },
        qui_delete () {
            this.qui.pop();
            this.qui2.pop();
        },
        qui_get () {
            getWithParams('/admin/qui_auto').then(data => {
                const res = JSON.stringify(data);
                this.qui_list = JSON.parse(res);
                this.autocomplete_list = this.qui_list;
            });
        },
        worker_add () {
            postWithParams('/api/post/workers', { valjson: JSON.stringify(this.qui2), id: this.idligne }).then((data) => {
                console.log(data);
            });
        },
        setSelected (value) {
            console.log(value);
            this.qui2.push({ 'qui_id': value.qui_id.id, 'order': value.order });
            console.log(this.qui2)
        }

    }
}
</script>

<style scoped>

</style>
