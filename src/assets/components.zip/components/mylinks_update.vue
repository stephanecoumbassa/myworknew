
<template>
    <div>
         <div v-for="item in links">
             <form @submit.prevent="link_update(item)">
                 <div class="row">
                     <div class="col-4">
                         <div class="form-group">
                             <label class="form-text text-dark">Type de lien</label>
                             <select v-validate="'required'" class="form-control search-slt" v-model="item.type" @input="$emit('blur', links)">
                                 <option>{{item.type}}</option>
                                 <option v-for="item in links_list"
                                         :value="item.id"
                                         :key="item.id"
                                 >{{item.name}}</option>
                             </select>
                         </div>
                     </div>
                     <div class="col-4">
                         <div class="form-group">
                             <label class="form-text text-dark">Lien</label>
                             <input v-validate="'required'" required class="form-control" type="url" v-model="item.name" />
                         </div>
                     </div>
                     <div class="col-4">
                         <label class="form-text text-dark">Actions</label>
                         <button type="button" class="btn btn-secondary btn-sm" v-on:click="link_delete(item)">supprimer</button>
                         <button type="submit" class="btn btn-primary btn-sm">modifier</button>
                     </div>
                 </div>
             </form>
         </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            links: {},
            country: '',
            links_list: ''
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.links_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.link_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        link_get () {
            getWithParams('/api/get/links', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                this.links = JSON.parse(data.links);
                console.log(this.links_list);
            })
        },
        links_get () {
            getWithParams('/api/get/links_type').then((data) => {
                console.log(data);
                this.links_list = data.links;
            // console.log(this.links_list);
            })
        },
        link_update (link) {
            if (confirm('Voulez vous modifier ?')) {
                putWithParams('/api/put/links', link).then((data) => {
                    console.log(data);
                });
            }
        },
        link_delete (link) {
            console.log(link.id);
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/links', { data: { id: link.id } }).then((data) => {
                    console.log(data);
                });
            }
        }
    }
}
</script>

<style scoped>

</style>
