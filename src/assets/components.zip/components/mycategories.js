Vue.component('mycategories', {
    delimiters: ['${', '}'],
    props: {
        typerubrique: Number
        // idcat: Number,
    },
    data: function () {
        return {
            count: 0,
            categories_list: '',
            idcat: 0,
            categories_master_list: '',
            categories: '',
            scategories: '',
            categories_initiales: ''
        }
    },
    created: function () {
        this.categories_get();
        this.categories_master_get();
    },
model: {
        event: 'blur'
    },
    watch: {
        // idcat: {
        //     immediate: true,
        //     handler (val, oldVal) {
        //         // this.contacts_get();
        //     }
        // }
    },
    methods: {
        handleInput () {
            this.$emit('blur', { cat: this.categories, scat: this.idcat });
            console.log(console.log(this.idcat));
            // {cat: categories, scat: idcat}
        },
        categoriesfilter () {
            console.log(this.categories_list);
            console.log(this.categories_master_list);
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            this.categories_list = cats;
        },
        categories_get () {
            getWithParams('/api/get/categories', { id: this.typerubrique }).then(data => {
                const res = JSON.stringify(data);
                this.categories_list = JSON.parse(res);
                this.categories_initiales = this.categories_list;
                console.log(this.categories_initiales);
            });
        },
        categories_master_get () {
            getWithParams('/api/get/categories_master', { id: this.typerubrique }).then(data => {
                const res = JSON.stringify(data);
                this.categories_master_list = JSON.parse(res);
                // console.log(this.categories_master_list);
            });
        }
    },
    template: '  <div> \
     \
                    <div class="form-group">\
                        <label class="form-text text-dark">Categories Parentes</label>\
                        <select class="form-control search-slt" v-on:change="categoriesfilter" v-model="categories" @input="$emit(\'blur\',{cat: categories, scat: idcat})">\
                            <option></option>\
                            <option v-for="cat in categories_master_list"\
                                    :value="cat.id"\
                                    :key="cat.id"\
                                    >${cat.name}</option>\
                        </select>\
                    </div>\
                    \
                    \<div class="form-group">\
                        <label class="form-text text-dark">Sous Categories</label>\
                        <select class="form-control search-slt" v-model="idcat" name="idcat" v-on:change="handleInput">\
                            <option value="0"> Selectionner une categorie </option>\
                            <option v-for="scat in categories_list"\
                                    :value="scat.id"\
                                    :key="scat.id">${scat.name}</option>\
                        </select>\
                    </div>\
                </div>\
            '
});
