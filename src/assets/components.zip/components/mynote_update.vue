<template>
    <div>
        <div v-for="note in notes_list">
            <form @submit.prevent="note_update(note)">
                <div class="row">
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">latitude</label>
                                    <input class="form-control" type="text" v-model="note.note" />
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">description</label>
                                    <textarea class="form-control" v-model="note.description"></textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Actions</label>
                                    <button type="button" class="btn btn-secondary btn-sm" v-on:click="notes_delete(note)">Supprimer</button>
                                    <button type="submit" class="btn btn-primary btn-sm" v-on:click="notes_update(note)">modifier</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            notes: [{ 'country_id': null, 'city_id': null, 'quartier_id': null, 'longlat': null, 'description': null }],
            country: '',
            city: '',
            cities_list: '',
            city_initiales: '',
            quartier: '',
            quartiers_list: '',
            quartier_initiales: '',
            notes_list: '',
            url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png',
            zoom: 10,
            center: [5.331869883252284, -4.00438422611056],
            bounds: null,
            markerLatLng: [5.331869883252284, -4.00438422611056]
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.cities_get();
        this.quartiers_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.notes_get();
            }
        }
    },
    methods: {
        realMarkerAdd (e) {
            console.log(this.notes[0]);
            const i = this.notes.length - 1;
            this.notes[i].latitude = e.target._latlng.lat;
            this.notes[i].longitude = e.target._latlng.lng;
        },
        openPopup: function (event) {
            console.log(event.target);
            event.target.openPopup();
        },
        zoomUpdated (zoom) {
            this.zoom = zoom;
        },
        centerUpdated (center) {
            this.center = center;
        },
        boundsUpdated (bounds) {
            this.bounds = bounds;
        },
        getLongLat () {
            console.log(this.markerLatLng)
        },
        notes_get () {
            getWithParams('/api/get/notes', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                // console.log(data);
                // console.log(data.notes);
                this.notes_list = JSON.parse(data.notes);
                console.log(this.notes_list);
            })
        },
        handleInput (value) {
            this.$emit('blur', value)
        },
        categoriesfilter () {
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        cities_get () {
            getWithParams('/api/get/cities_list', { id: this.country_id }).then(data => {
                const res = JSON.stringify(data);
                this.cities_list = JSON.parse(res);
                this.city_initiales = this.cities_list;
                console.log(this.city_initiales);
                console.log(data);
            });
        },
        quartiers_get () {
            getWithParams('/api/get/quartiers', { id: this.city_id }).then(data => {
                const res = JSON.stringify(data);
                this.quartiers_list = JSON.parse(res);
                this.quartier_initiales = this.quartiers_list;
                console.log(this.quartier_initiales);
            });
        },
        note_update (note) {
            if (confirm('Voulez vous modifier ?')) {
                this.$validator.validateAll().then((success) => {
                    if (success) {
                        console.log(note);
                        putWithParams('/api/put/notes', note).then((data) => {
                            console.log(data);
                        });
                    }
                });
            }
        },
        note_delete (note) {
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/notes', { data: { id: note.id } }).then((data) => {
                    console.log(data);
                });
            }
        }
    }
}
</script>

<style scoped>

</style>
