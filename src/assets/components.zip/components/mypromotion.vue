<template>
    <div>
        <form @submit.prevent="promotion_add()">

            <div class="row">
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Date Debut</label>
                        <input v-validate="'required'" required class="form-control" name="date_start"
                               type="date" v-model="item.date_start" @input="$emit('blur', promotions)" />
                        <span>{{ errors.first('date_start') }}</span>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Date de fin</label>
                        <input v-validate="'required'" required class="form-control" type="date" v-model="item.date_end" />
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Code Promo</label>
                        <input class="form-control" type="text" v-model="item.code_promo" />
                    </div>
                </div>
                <div class="col-8">
                    <div class="form-group">
                        <label class="form-text text-dark">Description</label>
                        <textarea v-validate="'required'" class="form-control" v-model="item.description">
                        </textarea>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Actions</label>
                        <button v-if="check_status" type="button" class="btn btn-secondary btn-sm" v-on:click="promotion_delete(item)">Supprimer</button>
                        <button v-if="check_status" type="button" class="btn btn-primary btn-sm" v-on:click="promotion_update(item)">modifier</button>
                        <button v-if="!check_status" type="submit" class="btn btn-secondary btn-sm">Ajouter</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            item: {},
            promotions: [],
            country: '',
            promotions_list: '',
            check_status: false
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.promotions_get();
                this.item.id = this.idligne;
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        promotion_add () {
            this.$validator.validateAll().then((success) => {
                if (success) {
                    postWithParams('/api/post/promotions', this.item).then((data) => {
                        console.log(data);
                        this.check_status = true;
                        this.promotions_get();
                    });
                }
            });
        },
        promotions_get () {
            getWithParams('/api/get/promotions', { id: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                if (data.promotions == null) {
                    this.check_status = false;
                } else {
                    this.check_status = true;
                    this.promotions_list = JSON.parse(data.promotions);
                    this.item = this.promotions_list[0];
                    console.log(this.item);
                }
            })
        },
        promotion_update (promotion) {
            if (confirm('Voulez vous modifier ?')) {
                putWithParams('/api/put/promotions', promotion).then((data) => {
                    console.log(data);
                    this.promotions_get();
                    this.check_status = true;
                });
            }
        },
        promotion_delete (promotion) {
            console.log(promotion.id);
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/promotions', { data: { id: promotion.id } }).then((data) => {
                    console.log(data);
                    this.check_status = false;
                    this.promotions_get();
                });
            }
        },
        promotion_a () {
            this.promotions.push({});
        },
        capacities_delete () {
            this.promotions.pop();
        }
    }
}
</script>

<style scoped>

</style>
