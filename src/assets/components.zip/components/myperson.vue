<template>
    <div>
        <!--
        <div v-for="newperson in newpersons" :key='newperson.id'>
            <mynewperson :idligne="idligne"></mynewperson>
        </div>
        <br>
        <button type="button" class="btn btn-secondary btn-sm" v-on:click="newperson_delete">-</button>
        <button type="button" class="btn btn-primary btn-sm" v-on:click="newperson_add">+</button>
        -->
        <div class="row">
            <div v-for="item in persons" :key='item.id' class="col-4">
                <div class="card">
                    <div class="card-body">
                        {{item.fullname}}<br>
                        {{item.date_start}}<br>
                        {{item.date_end}}<br>
                        {{item.fonction}}<br>
                        {{item.ordre}}<br>
                    </div>
                    <div class="card-footer">
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="person_delete(item.id)">Supprimer</button>
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="update(item)">Modifier</button>
                    </div>
                </div>
            </div>
        </div>
        <form>
            <div v-for="(p, index) in person" :key='index'>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Ordre Hierachique</label>
                            <input class="form-control" type="text"  v-model="p.order">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Fonctions</label>
                            <input class="form-control" type="text"  v-model="p.fonction">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Date debut</label>
                            <input class="form-control" type="date"  v-model="p.date_start">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Date fin</label>
                            <input class="form-control" type="date"  v-model="p.date_end">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <label class="form-text text-white"> - </label>
                            <button class="btn btn-sm btn-secondary" type="button" v-on:click="persons_get()"> Actualiser</button>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <!-- @keypress.native="select1" -->
                            <!-- @input="select2(index)" -->
                            <label class="form-text text-dark">Personnes</label>
                            <v-select required label="fullname" @input="select2(index)" v-model="p.personnes" :options="autocomplete_list">
                                <template slot="option" slot-scope="option">
                                    <span class="fa fa-home"></span>
                                    {{ option.id}} - {{ option.fullname}}
                                </template>
                            </v-select>
                        </div>
                    </div>
                </div>
                 <button v-on:click="person_update(p)" class="btn btn-primary" type="button">Modifier</button>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" v-on:click="person_delete">-</button>
            <button type="button" class="btn btn-primary btn-sm" v-on:click="person_add">+</button>
            <button type="button" class="btn btn-primary btn-sm" v-on:click="persons_add()">Ajouter</button>
        </form>

    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            autocomplete_list: [],
            autocomplete_list2: [],
            autocomplete_initiales: '',
            count: 0,
            newperson: {},
            newpersons: [{}],
            person: [{ 'personnes': { 'id': null }, 'order': 1, 'date_end': null, 'fonction': 'Directeur Général' }],
            person2: [],
            persons: [],
            qui: [],
            qui2: [],
            qui_list: '',
            person_list: '',
            val: '',
            add: false
        }
    },
    components: {
        'mynewperson': httpVueLoader('js/components/mynewperson.vue')
    },
    created: function () {
        this.persons_get();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.person_get_by_compagny();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        select1 () {
            console.log('SELECT 1');
        },
        select2 (index) {
            this.person[index].personnes_id = this.person[index].personnes.id;
            console.log(this.person);
        },
        person_add () {
            this.person.push({ 'personnes': { 'id': null }, 'order': 1, 'date_end': null, 'fonction': 'Directeur Général' });
            // console.log(this.qui);
        },
        show () {
            this.add = !this.add
        },
        person_delete () {
            this.person.pop();
            this.qui2.pop();
        },
        newperson_add () {
            this.newpersons.push({ 'personnes': { 'id': null }, 'order': 1, 'date_end': null, 'fonction': null });
        },
        newperson_delete () {
            this.newpersons.pop();
        },
        person_get_by_compagny () {
            getWithParams('/api/get/persons_company', { id: this.idligne }).then(data => {
                console.log(data);
                this.persons = data;
                console.log(this.persons);
            });
        },
        persons_get () {
            getWithParams('/api/get/persons').then(data => {
                const res = JSON.stringify(data);
                this.person_list = JSON.parse(res);
                this.autocomplete_list = this.person_list;
            });
        },
        qui_get () {
            getWithParams('/admin/qui_auto').then(data => {
                const res = JSON.stringify(data);
                this.qui_list = JSON.parse(res);
                this.autocomplete_list2 = this.qui_list;
            });
        },
        person_add_one () {
            if (confirm('Voulez vous ajouter ?')) {
                this.newperson.qui_id = this.newperson.qui_id.id;
                console.log(this.newperson);
                postWithParams('/api/post/persons_one',
                               { valjson: JSON.stringify(this.newperson), id: this.idligne }).then((data) => {
                                   console.log(data);
                                   this.person_get_by_compagny();
                               });
            }
        },
        persons_add () {
            if (confirm('Voulez vous ajouter ?')) {
                // for (let i = 0; i < this.person.length; i++) {
                //     this.person[i].personnes_id = this.person[i].personnes.id;
                // }
                console.log(this.person);
                postWithParams('/api/post/pj_persons', { valjson: JSON.stringify(this.person), id: this.idligne }).then((data) => {
                    console.log(data);
                    this.person_get_by_compagny();
                });
            }
        },
        setSelected () {
            console.log(value);
            this.qui2.push({ 'qui_id': value.qui_id.id, 'order': value.order });
            console.log(this.qui2)
        },
        person_delete (id) {
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/persons/' + id).then((data) => {
                    console.log(data);
                    this.person_get_by_compagny();
                }, (error) => {
                    console.log(error)
                });
            }
        },
        person_update (person) {
            if (confirm('Voulez vous modifier ?')) {
                putWithParams('/api/put/persons_relations',
                              {
                                  personne_id: person.personnes_id,
                                  ordre: person.ordre,
                                  fonction: person.fonction,
                                  date_start: person.date_start,
                                  date_end: person.date_end,
                                  id: person.id
                              }
                ).then((data) => {
                    console.log(data);
                    this.person_get_by_compagny();
                }, (error) => {
                    console.log(error)
                });
            }
        },
        update (person) {
            console.log(person);
            person.order = person.ordre;
            this.person = [person];
            this.update_status = true;
        }
    }
}
</script>

<style scoped>

</style>
