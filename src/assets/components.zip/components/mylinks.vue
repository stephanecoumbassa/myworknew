<template>
    <div>
        <form @submit.prevent="link_post">
            <div v-for="item in links">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Type de lien</label>
                            <select v-validate="'required'" required class="form-control search-slt" v-model="item.type" @input="$emit('blur', links)">
                                <option></option>
                                <option v-for="item in links_list"
                                        :value="item.id"
                                        :key="item.id"
                                >{{item.name}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Lien</label>
                            <input v-validate="'required|url'" required class="form-control" type="url" v-model="item.name" />
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" v-on:click="link_delete">-</button>
            <button type="button" class="btn btn-primary btn-sm" v-on:click="link_add">+</button>
            <button type="submit" class="btn btn-primary btn-sm">Ajouter</button>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            // links: [{'type': null, 'name': null}],
            links: [],
            links_list: ''
        }
    },
    created: function () {
        this.links_get();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.link_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        links_get () {
            getWithParams('/admin/links').then(data => {
                const res = JSON.stringify(data);
                this.links_list = JSON.parse(res);
                console.log(this.links_list);
            });
        },
        link_post () {
            postWithParams('/api/post/links', {
                links: this.links,
                id: this.idligne,
                typerubrique: this.typerubrique
            }).then((data) => {
                console.log(data);
            });
        },
        link_add () {
            this.links.push({ 'type': null, 'name': null });
        },
        link_delete () {
            this.links.pop();
        }
    }
}
</script>

<style scoped>

</style>
