<template>

        <form @submit.prevent="address_post">
            <div v-for="address in addresses">
                <div class="row">
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Pays</label>
                                    <select v-validate="'required'" required class="form-control search-slt"
                                            v-model="address.country_id" @input="$emit('blur', addresses)">
                                        <option value="1">RCI</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Ville</label>
                                    <select v-validate="'required'" required class="form-control search-slt"
                                            v-model="address.city_id" v-on:change="quartierfilter(address.city_id)">
                                        <option v-for="item in cities_list"
                                                :value="item.id"
                                                :key="item.id">
                                            {{item.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Commune / Quartier</label>
                                    <select class="form-control search-slt" v-model="address.quartier_id">
                                        <option v-for="q in quartiers_list" :value="q.id">{{q.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">description</label>
                                    <textarea class="form-control" v-model="address.description"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div> <button class="btn btn-secondary" type="button" v-on:click="s1 = !s1">Afficher/Masquer la carte/</button>

                        <div style="height: 310px; width: 100%, display: block" v-if="s1">
                            <div class="info" style="height: 15%">
                                <span>latLong: {{ address.latitude }} - {{ address.longitude }}</span><br>
                            </div>
                            <l-map ref="myMap" :zoom="zoom" :center="center" @update:zoom="zoomUpdated"
                                    @update:center="centerUpdated" @update:bounds="boundsUpdated" >
                                <l-tile-layer :url="url"></l-tile-layer>
                                <l-marker :lat-lng="markerLatLng" :draggable="true" v-on:dragend="realMarkerAdd"
                                 :update="markerLatLng" :ready="realMarkerAdd"></l-marker>
                            </l-map>
                        </div>
                    </div>
                </div>

                <br><br>
                <div class="col-lg-4">
                    <!--<button type="button" class="btn btn-secondary btn-sm" v-on:click="address_delete">-</button>
                    <button type="button" class="btn btn-primary btn-sm" v-on:click="address_add">+</button>-->
                    <button v-if="!status_update" type="submit" class="cta sm">Ajouter</button>
                    <button v-if="status_update"  type="button" class="cta sm" v-on:click="address_delete(address)">Supprimer</button>
                    <button v-if="status_update"  type="button" class="cta sm" v-on:click="address_update(address)">modifier</button>
                </div>

            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            s1: false,
            count: 0,
            addresses: [{}],
            country: '',
            city: '',
            city_id: '',
            cities_list: '',
            city_initiales: '',
            quartier: '',
            quartiers_list: '',
            quartier_initiales: '',
            addresses_list: '',
            status_update: true,
            url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png',
            zoom: 10,
            center: [5.331869883252284, -4.00438422611056],
            bounds: null,
            markerLatLng: [5.331869883252284, -4.00438422611056],
            myMap: '',
            mapObject: '',
            window: {
                width: 0,
                height: 0
            }
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.cities_get();
        this.quartiers_get();
        // this.addresses_get();
        window.addEventListener('resize', this.handleResize);
        this.handleResize();
    },
    model: {
        // event: 'blur'
    },
    destroyed () {
        window.removeEventListener('resize', this.handleResize)
    },
    mounted () {
        this.$nextTick(() => {
            setTimeout(() => {
                this.s1 = true;
            }, 5000);
            // this.$refs.myMap[0].mapObject.invalidateSize();
            // this.$refs.myMap[0].mapObject.resizeMap();
        })
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.addresses_get();
            }
        }
    },
    methods: {
        handleResize () {
            console.log('resized')
        },
        resize () {
            this.window.width = this.window.width - 100;
        },
        handleResize () {
            this.window.width = window.innerWidth + 1;
            this.window.height = window.innerHeight + 1;
        },
        resizeMap () {
            if (this.$refs.myMap[0].mapObject) {
                this.$refs.myMap[0].mapObject.invalidateSize();
                // Workaround to re-open popups at their correct position.
                this.$refs.myMap[0].mapObject.eachLayer((layer) => {
                    if (layer instanceof L.Marker) {
                        layer.openPopup();
                    }
                });
            }
        },
        realMarkerAdd (e) {
            const i = this.addresses.length - 1;
            this.addresses[i].latitude = e.target._latlng.lat;
            this.addresses[i].longitude = e.target._latlng.lng;
            console.log(this.addresses)
        },
        openPopup: function (event) {
            console.log(event.target);
            event.target.openPopup();
        },
        zoomUpdated (zoom) {
            this.zoom = zoom;
        },
        centerUpdated (center) {
            this.center = center;
        },
        boundsUpdated (bounds) {
            this.bounds = bounds;
        },
        getLongLat () {
            console.log(this.markerLatLng)
        },
        addresses_get () {
            getWithParams('/api/get/addresses', { idligne: this.idligne, typerubrique: this.typerubrique })
                .then((data) => {
                    this.addresses_list = JSON.parse(data.addresses);
                    this.addresses = JSON.parse(data.addresses);
                    this.status_update = true;
                    if (this.addresses === null) {
                        this.addresses = [{}];
                        this.status_update = false;
                        return;
                    };
                    this.markerLatLng = [parseFloat(this.addresses[0].latitude), parseFloat(this.addresses[0].longitude)];
                    console.log(this.addresses_list);
                })
        },
        handleInput (value) {
            this.$emit('blur', value)
        },
        categoriesfilter () {
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        cities_get () {
            getWithParams('/api/get/cities_list', { id: this.country_id }).then(data => {
                const res = JSON.stringify(data);
                this.cities_list = JSON.parse(res);
                this.city_initiales = this.cities_list;
                console.log(this.city_initiales);
                console.log(data);
            });
        },
        quartiers_get (_id) {
            getWithParams('/api/get/quartiers', { id: _id }).then(data => {
                const res = JSON.stringify(data);
                this.quartiers_list = JSON.parse(res);
                this.quartier_initiales = this.quartiers_list;
                console.log(this.quartier_initiales);
            });
        },
        address_post () {
            this.$validator.validateAll().then((success) => {
                if (success) {
                    postWithParams('/api/post/addresses', { addresses: this.addresses, id: this.idligne, typerubrique: this.typerubrique })
                        .then((data) => {
                            this.addresses_get();
                        });
                }
            });
        },
        address_update (address) {
            if (confirm('Voulez vous modifier ?')) {
                this.$validator.validateAll().then((success) => {
                    if (success) {
                        console.log(address);
                        putWithParams('/api/put/addresses', address).then((data) => {
                            this.addresses_get();
                        });
                    }
                });
            }
        },
        address_delete (address) {
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/addresses', { data: { id: address.id } })
                    .then((data) => {
                        this.addresses_get();
                    });
            }
        },
        quartierfilter (city_id) {
            this.quartiers_list = this.quartier_initiales;
            let quarts = this.quartiers_list.filter((quart) => {
                return quart.city_id === String(city_id);
            });
            this.quartiers_list = quarts;
        }
        /*
            address_add(){
                this.addresses.push({'country_id': null, 'city_id': null, 'latitude': null, 'longitude': null, 'description': null});
            },
            address_delete(){
                this.addresses.pop();
            } */
    }
}
</script>

<style scoped>

</style>
