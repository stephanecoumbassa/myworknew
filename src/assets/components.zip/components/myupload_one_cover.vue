<template>
    <div>
        <form>
            <div class="row">
                <div class="col-12">
                    <input ref=fileInputActivator type="file" @change="fileChange">
                    <vue-croppie ref=croppieRef
                                 :enable-orientation="true"
                                 @result="result"
                                 @update="update"
                                 :enable-resize="true"
                                 :enable-exif="true"
                                 :boundary="{width:1200, height:200}"
                                 :viewport="{width: myWidth, height: myHeight, type: 'square'}">

                    </vue-croppie>
                </div>
                <br>
                <br>
                <div class="col-12">
                    <button type="button" @click="rotate(-90)">Rotation Gauche</button>
                    <button type="button" @click="rotate(90)">Rotation Droite</button>
                    <button type="button" @click="crop()">Crop</button>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-text text-dark">Type de lien</label>
                        <select v-validate="'required'" required class="form-control search-slt" v-model="type">
                            <option></option>
                            <option v-for="item in medias_type"
                                    :value="item.id"
                                    :key="item.id"
                            >{{item.name}}</option>
                        </select>
                    </div>
                </div>
                <div class="col-12">
                    <img v-bind:src="cropped" style="height: 200px; width: 1200px">
                </div>
                <div class="col-12">
                    <button type="button" v-on:click="reset" class="btn btn-sm btn-secondary">Reset</button>
                    <button type="button" class="btn btn-sm btn-primary" v-on:click="medias_add">Ajouter</button>
                </div>

            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            image: null,
            type: [],
            image_name: '',
            myHeight: 200,
            myWidth: 1200,
            myViewport: {},
            image_extension: 'jpg',
            who: 'Stefyu',
            medias_list: [{ image: '' }],
            medias_type: [],
            cropped: null,
            images: [
                this.image,
                this.image
            ]
        }
    },
    props: {
        typerubrique: Number,
        idligne: Number,
        folder: String,
        default: String,
        cropper: Boolean,
        cropperWidth: {
            type: Number,
            default: 1400
        },
        src: String
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
            // this.medias_get();
            }
        }
    },

    mounted () {
        this.$refs.croppieRef.bind({
            url: 'http://i.imgur.com/Fq2DMeH.jpg'
        })
    },
    created: function () {
        this.medias_get();
    },
    model: {
        event: 'change'
    },
    methods: {
        handleInput (value) {
            this.$emit('change', value)
        },
        cropSize () {
        },
        onFileChange (e) {
            console.log(e);
            var files = e.target.files || e.dataTransfer.files;
            if (!files.length) { return; }
            this.createImage(files[0]);
        },
        medias_get () {
            getWithParams('/api/get/medias_type').then(data => {
                const res = JSON.stringify(data);
                this.medias_type = JSON.parse(res);
            });
        },
        createImage (file) {
            console.log(file);
            var a = file.name.split('.');
            this.image_name = file.name;
            this.image_extension = a[1];

            var image = new Image();
            var reader = new FileReader();
            var vm = this;

            reader.onload = (e) => {
                vm.image = e.target.result;
                this.handleInput(vm.image)
            };
            reader.readAsDataURL(file);
        },
        removeImage: function (e) {
            this.image = '';
        },
        reset () {
            this.image = null;
            this.image_name = '';
            this.image_extension = '';
        },
        medias_add () {
            if (confirm('Voulez vous ajouter ?')) {
                postWithParams('/api/post/medias_one',
                               {
                                   'typerubrique': this.typerubrique,
                                   'type': this.type,
                                   'id': this.idligne,
                                   'folder': this.folder,
                                   'image_extension': this.image_extension,
                                   'image': this.image,
                                   'image_name': this.image_name
                               }
                )
                    .then(data => {
                        console.log(data)
                    });
            }
        },
        medias_delete () {
            this.medias_list.pop();
        },
        bind () {
            // Randomize cat photos, nothing special here.
            let url = this.images[Math.floor(Math.random() * 4)];

            // Just like what we did with .bind({...}) on
            // the mounted() function above.
            this.$refs.croppieRef.bind({
                url: url
            });
        },
        // CALBACK USAGE
        crop () {
            let options = {
                format: this.image_extension,
                circle: false
            };
            this.$refs.croppieRef.result(options, (output) => {
                this.cropped = output;
                this.image = output;
            });
        },
        // EVENT USAGE
        cropViaEvent () {
            this.$refs.croppieRef.result(options);
        },
        result (output) {
            this.cropped = output;
            this.image = output;
        },
        update (val) {
            console.log(val);
        },
        rotate (rotationAngle) {
            // Rotates the image
            this.$refs.croppieRef.rotate(rotationAngle);
        },
        fileChange (file) {
            // To check if file is an image
            if (!file.target.files[0].name.match(/.(jpg|jpeg|png|gif)$/i)) {
                console.warn('not an image');
                file.target.value = null;
                this.$emit('imageChanged', null);
                return;
            }
            this.image_name = file.target.files[0].name;
            var a = file.target.files[0].name;
            this.image_extension = a[1];

            console.log(this.image_name);
            console.log(this.image_extension);

            var reader = new FileReader();
            reader.readAsDataURL(file.target.files[0]);
            reader.onload = () => {
                this.dialog = true;
                // bind the result of the file
                // to croppie
                this.$refs.croppieRef.bind({
                    url: reader.result
                });
                file.target.value = null
            };
            reader.onerror = (error) => {
                console.log('Error: ', error);
            };
        }
    }
}
</script>

<style scoped>
    #app {
        text-align: center;
    }
    img {
        width: 30%;
        margin: auto;
        display: block;
        margin-bottom: 10px;
    }
    button {

    }
    /*.cr-boundary{*/
    /*    width: 500px !important;*/
    /*}*/
</style>
