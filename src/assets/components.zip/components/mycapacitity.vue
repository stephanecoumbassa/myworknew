<template>
    <div>
        <div class="row">
            <div v-if="capacities_list.length >=1" v-for="item in capacities_list" class="col-3">
                <div class="card">
                    <div class="card-body">
                        {{item.value}}<br>
                        {{item.type_name}}<br>
                        {{item.unity}}<br>
                    </div>
                    <div class="card-footer">
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="capacity_delete(item)">Supprimer</button>
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="update(item)">Modifier</button>
                    </div>
                </div>
            </div>
        </div>
        <form @submit.prevent="capacities_post">
            <div v-for="item in capacities">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Champs</label>
                            <select v-validate="'required'" required class="form-control" v-model="item.type" @input="$emit('blur', capacities)">
                                <option></option>
                                <option v-for="capacity in capacities_type_list"
                                        :value="capacity.id"
                                        :key="capacity.id"
                                >{{capacity.name}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Valeur</label>
                            <input v-validate="'required'" required class="form-control" type="number" v-model="item.value" />
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Unite</label>
                            <input required class="form-control" type="text" v-model="item.unity" />
                        </div>
                    </div>
                    <input v-if="update_status" class="btn btn-primary" type="button"
                     name="submit" value="modifier" v-on:click="capacity_update(item)">
                    <br>
                </div>
            </div>
            <button v-if="!update_status" type="button" class="btn btn-secondary btn-sm" v-on:click="capacities_delete">-</button>
            <button v-if="!update_status" type="button" class="btn btn-primary btn-sm" v-on:click="capacities_add">+</button>
            <button v-if="!update_status" type="submit" class="btn btn-primary btn-sm">Ajouter</button>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            update_status: false,
            capacities: [{}],
            capacities_list: '',
            capacities_type_list: []
        }
    },
    created: function () {
        this.capacities_get();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.capacity_get();
                this.capacities_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        capacity_get () {
            getWithParams('/api/get/capacities', { id: this.idligne }).then((data) => {
                console.log(data);
                this.capacities_list = JSON.parse(data.capacities);
                console.log(this.capacities);
            })
        },
        capacities_get () {
            getWithParams('/admin/capacities').then(data => {
                this.capacities_type_list = data;
                console.log(this.capacities_type_list);
            });
        },
        capacities_post () {
            if (confirm('Voulez vous ajouter ?')) {
                postWithParams('/api/post/capacities', {
                    capacities: this.capacities,
                    id: this.idligne,
                    typerubrique: this.typerubrique
                }).then((data) => {
                    console.log(data);
                    this.capacity_get();
                    this.capacities = [{}];
                });
            }
        },
        capacity_delete (capacity) {
            console.log(capacity.id);
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/capacities', { data: { id: capacity.id } }).then((data) => {
                    console.log(data);
                    this.capacity_get();
                    this.capacities = [{}];
                });
            }
        },
        capacity_update (capacity) {
            this.update_status = false;
            if (confirm('Voulez vous modifier ?')) {
                putWithParams('/api/put/capacities', capacity).then((data) => {
                    console.log(data);
                    this.capacity_get();
                    this.capacities = [{}];
                });
            }
        },
        update (capacity) {
            this.capacities = [capacity];
            this.update_status = true;
            console.log(this.capacities);
        },
        capacities_add () {
            this.capacities.push({ 'type': null, 'value': null, 'unity': null });
        },
        capacities_delete () {
            this.capacities.pop();
        }
    }
}
</script>

<style scoped>

</style>
