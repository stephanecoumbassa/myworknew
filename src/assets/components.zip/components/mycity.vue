<template>
    <div>
        <div v-for="item in cities">
            <form @submit.prevent="city_post">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Country</label>
                            <select  v-validate="'required'" required class="form-control search-slt" v-model="item.country_id">
                                <option></option>
                                <option v-for="c in country_list" :value="c.id">{{c.name}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Ville</label>
                            <input  v-validate="'required'" required class="form-control" type="text" v-model="item.name" />
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <button type="button" class="btn btn-secondary btn-sm" v-on:click="city_delete">-</button>
                    <button type="button" class="btn btn-primary btn-sm" v-on:click="city_add">+</button>
                    <button type="submit" class="btn btn-primary btn-sm">Ajouter</button>
                </div>

            </form>
        </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            country: '',
            country_list: {},
            cities: [{}],
            countries: [{}],
            city: '',
            countries_list: '',
            cities_list: '',
            city_initiales: '',
            quartier: '',
            quartiers_list: '',
            quartier_initiales: ''
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.country_get();
        // this.quartiers_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {

            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        categoriesfilter () {
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        country_get () {
            getWithParams('/api/get/country').then(data => {
                console.log(data);
                this.country_list = data;
            });
        },
        cities_get () {
            getWithParams('/api/get/cities', { id: this.country_id }).then(data => {
                const res = JSON.stringify(data);
                this.cities_list = JSON.parse(res);
                this.city_initiales = this.cities_list;
                console.log(this.city_initiales);
                console.log(data);
            });
        },
        quartiers_get () {
            getWithParams('/api/get/quartiers', { id: this.city_id }).then(data => {
                const res = JSON.stringify(data);
                this.quartiers_list = JSON.parse(res);
                this.quartier_initiales = this.quartiers_list;
                console.log(this.quartier_initiales);
            });
        },
        city_post () {
            postWithParams('/api/post/cities', { countries: this.countries }).then((data) => {
                console.log(data);
            });
        },
        city_add () {
            this.cities.push({ 'name': null, 'code': null, 'indicatif': null });
        },
        city_delete () {
            this.cities.pop();
        }
    }
}
</script>

<style scoped>

</style>
