<template>
    <div>
        <div v-for="item in promotions_list">
            <form @submit.prevent="promotion_update(item)">
            <div class="row">
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Date Debut</label>
                        <input required class="form-control" type="date" v-model="item.date_start" @input="$emit('blur', promotions)" />
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Date de fin</label>
                        <input required class="form-control" type="date" v-model="item.date_end" />
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Code Promo</label>
                        <input class="form-control" type="text" v-model="item.code_promo" />
                    </div>
                </div>
                <div class="col-8">
                    <div class="form-group">
                        <label class="form-text text-dark">Description</label>
                        <textarea required class="form-control" v-model="item.description">
                        </textarea>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Actions</label>
                        <button type="button" class="btn btn-secondary btn-sm" v-on:click="promotion_delete(item)">Supprimer</button>
                        <button type="button" class="btn btn-primary btn-sm" v-on:click="promotion_update(item)">modifier</button>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            promotions: [{}],
            country: '',
            promotions_list: []
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.promotions_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        promotions_get () {
            getWithParams('/api/get/promotions', { id: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                this.promotions_list = JSON.parse(data.promotions);
                console.log(this.promotions_list);
            })
        },
        promotion_update (promotion) {
            if (confirm('Voulez vous modifier ?')) {
                putWithParams('/api/put/promotions', promotion).then((data) => {
                    console.log(data);
                    this.promotions_get();
                });
            }
        },
        promotion_delete (promotion) {
            console.log(promotion.id);
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/promotions', { data: { id: promotion.id } }).then((data) => {
                    console.log(data);
                    this.promotions_get();
                });
            }
        }
    }
}
</script>

<style scoped>

</style>
