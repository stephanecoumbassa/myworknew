<template>
    <div>
        <form>
            <div class="" v-if="this.week">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" :value="week.j1" v-model="week.j1">
                            <label class="form-check-label">Fermer / Ouvert</label>
                        </div>
                    </div>
                    <div class="col-4">
                        <!--                <input v-if="week.j1 != 0" class="form-control" type="time" v-model="week.j1_start" @input="$emit('blur', week)">-->
                        <input class="form-control" type="time" v-model="week.j1_start" @input="$emit('blur', week)">
                    </div>
                    <div class="col-4">
                        <input class="form-control" type="time" v-model="week.j1_end">
                        <!--                <input v-if="week.j1 != 0" class="form-control" type="time" v-model="week.j1_end">-->
                    </div>
                </div>

                <div class="row">
                    <div class="col-4">
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" v-model="week.j2">
                            <label class="form-check-label">Fermer / Ouvert</label>
                        </div>
                    </div>
                    <div class="col-4">
                        <input v-if="week.j2" class="form-control" type="time" v-model="week.j2_start" @input="$emit('blur', week)">
                    </div>
                    <div class="col-4">
                        <input v-if="week.j2" class="form-control" type="time" v-model="week.j2_end">
                    </div>
                </div>

                <div class="row">
                    <div class="col-4">
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" v-model="week.j3">
                            <label class="form-check-label">Fermer / Ouvert</label>
                        </div>
                    </div>
                    <div class="col-4">
                        <input v-if="week.j3" class="form-control" type="time" v-model="week.j3_start" @input="$emit('blur', week)">
                    </div>
                    <div class="col-4">
                        <input v-if="week.j3" class="form-control" type="time" v-model="week.j3_end">
                    </div>
                </div>

                <div class="row">
                    <div class="col-4">
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" v-model="week.j4">
                            <label class="form-check-label">Fermer / Ouvert</label>
                        </div>
                    </div>
                    <div class="col-4">
                        <input v-if="week.j4" class="form-control" type="time" v-model="week.j4_start">
                    </div>
                    <div class="col-4">
                        <input v-if="week.j4" class="form-control" type="time" v-model="week.j4_end">
                    </div>
                </div>

                <div class="row">
                    <div class="col-4">
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" v-model="week.j5">
                            <label class="form-check-label">Fermer / Ouvert</label>
                        </div>
                    </div>
                    <div class="col-4">
                        <input v-if="week.j5" class="form-control" type="time" v-model="week.j5_start">
                    </div>
                    <div class="col-4">
                        <input v-if="week.j5" class="form-control" type="time" v-model="week.j5_end">
                    </div>
                </div>

                <div class="row">
                    <div class="col-4">
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" v-model="week.j6">
                            <label class="form-check-label">Fermer / Ouvert</label>
                        </div>
                    </div>
                    <div class="col-4" v-if="week.j6 !=0">
                        <input class="form-control" type="time" v-model="week.j6_start">
                    </div>
                    <div class="col-4" v-if="week.j6 !=0">
                        <input class="form-control" type="time" v-model="week.j6_end">
                    </div>
                </div>

                <div class="row">
                    <div class="col-4">
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" v-model="week.j7">
                            <label class="form-check-label">Fermer / Ouvert</label>
                        </div>
                    </div>
                    <div class="col-4" v-if="week.j7 !=0">
                        <input v-if="week.j7" class="form-control" type="time" v-model="week.j7_start">
                    </div>
                    <div class="col-4" v-if="week.j7 !=0">
                        <input v-if="week.j7" class="form-control" type="time" v-model="week.j7_end">
                    </div>
                </div>

                <button type="button" class="btn btn-secondary btn-sm" v-on:click="week_delete(week.PJ_ID)">supprimer</button>
                <button type="button" class="btn btn-primary btn-sm" v-on:click="week_update(week)">modifier</button>

            </div>

        </form>

    </div>

</template>

<script>
module.exports = {
    data: function () {
        return {
            // week: { PJ_ID: "1",
            //         id: "1",
            //         id_ligne: "1",
            //         j1: "1",
            //         j1_end: "18:00:00",
            //         j1_start: "06:00:00",
            //         j2: "1",
            //         j2_end: "18:00:00",
            //         j2_start: "06:00:00",
            //         j3: "1",
            //         j3_end: "18:00:00",
            //         j3_start: "06:00:00",
            //         j4: "1",
            //         j4_end: "18:00:00",
            //         j4_start: "06:00:00",
            //         j5: "1",
            //         j5_end: "18:00:00",
            //         j5_start: "06:00:00",
            //         j6: "0",
            //         j6_end: "00:00:00",
            //         j6_start: "00:00:00",
            //         j7: "0",
            //         j7_end: "00:00:00",
            //         j7_start: "00:00:00"
            //       },
            week: {},
            weeks_list: ''
        }
    },
    props: {
        idligne: Number
    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.week_get();
            }
        }
    },
    created: function () {
        this.week_get();
    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        week_get () {
            getWithParams('/api/get/horaires', { id: this.idligne }).then((data) => {
                console.log(data);
                this.week = data;
            })
        },
        week_update (week) {
            putWithParams('/api/put/horaires', { week: JSON.stringify(week), id: this.idligne }).then((data) => {
                console.log(data);
            });
        },
        week_delete (id) {
            deleteWithParams('/api/delete/horaires', { data: { id: id } }).then((data) => {
                console.log(data);
            });
        }

    }
}
</script>

<style scoped>

</style>
