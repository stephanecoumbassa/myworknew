<template>
    <div>
            <div v-for="item in contacts_list">
                <form @submit.prevent="contact_update(item)">
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">Email</label>
                                <input v-validate="'required'" required class="form-control" type="email" v-model="item.email" @input="$emit('blur', contacts)" />
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">Telephone</label>
                                <input v-validate="'required'" required class="form-control" type="text" v-model="item.telephone" />
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">Fax</label>
                                <input class="form-control" type="text" v-model="item.fax" />
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">BP</label>
                                <input class="form-control" type="text" v-model="item.bp" />
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">website</label>
                                <input class="form-control" type="text" v-model="item.website" />
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">Actions</label>
                                <button type="button" class="btn btn-secondary btn-sm" v-on:click="contact_delete(item)">Supprimer</button>
                                <button type="submit" class="btn btn-primary btn-sm">modifier</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            contacts: [{ 'id': null, 'email': null, 'telephone': null, 'fax': null }, { 'id': 1, 'email': 'test@test.fr', 'telephone': '77546221', 'fax': '' }],
            country: '',
            contacts_list: ''
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.contacts_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        contacts_get () {
            getWithParams('/api/get/contacts', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                this.contacts_list = JSON.parse(data.contacts);
                console.log(this.contacts_list);
            })
        },
        categoriesfilter () {
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        contact_update (contact) {
            if (confirm('Voulez vous modifier ?')) {
                putWithParams('/api/put/contacts', contact).then((data) => {
                    console.log(data);
                });
            }
        },
        contact_delete (contact) {
            console.log(contact.id);
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/contacts', { data: { id: contact.id } }).then((data) => {
                    console.log(data);
                });
            }
        }
    }
}
</script>

<style scoped>

</style>
