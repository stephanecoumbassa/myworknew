<template>
    <div>
            <div class="row">
                <div class="col-7">
                    <div class="form-group">
                        <label class="form-text text-dark">Champs</label>
                        <input class="form-control" name=""  v-model="speciality.name"/>
                    </div>
                </div>
                <div class="col-5">
                    <label class="form-text text-dark">.</label>
                    <button type="button" class="btn btn-primary" v-on:click="specialities_update">
                        Modifier une specialite
                    </button>
                </div>
            </div>

    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            item: [],
            speciality: ''
        }
    },
    props: {
        idligne: Number
    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.specialities_get()
            }
        }
    },
    created: function () {
        this.specialities_get()
    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        setSelected (value) {
            // console.log(value);
            this.valeur_json.push(value);
            console.log(this.valeur_json)
        },
        specialities_update () {
            console.log('update');
            putWithParams('/api/put/specialities_type', { id: this.idligne, name: this.speciality.name }).then(data => {
                console.log(data);
            });
        },
        specialities_get () {
            getWithParams('/api/get/specialities_type_one', { id: this.idligne }).then((data) => {
                const res = JSON.stringify(data);
                this.speciality = JSON.parse(res);
                console.log(this.speciality);
            })
        }
    }
}
</script>

<style scoped>

</style>
