<template>
    <div>
        <form @submit.prevent="contact_post">
        <div v-for="item in contacts">
            <div class="row">
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Email</label>
                        <input class="form-control" v-validate="'required|email'" name="email" type="email" v-model="item.email" @input="$emit('blur', contacts)" />
                        <span>{{ errors.first('email') }}</span>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Telephone</label>
                        <mycountries v-model="item.indicatif" ></mycountries>
                        <input class="form-control" v-validate="'required'" name="telephone" type="text" v-model="item.telephone" />
                        <span>{{ errors.first('telephone') }}</span>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Fax</label>
                        <input class="form-control" type="text" v-model="item.fax" />
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">BP</label>
                        <input class="form-control" type="text" v-model="item.bp" />
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">website</label>
                        <input class="form-control" v-validate="{url: {require_protocol: true }}" name="website" type=url v-model="item.website" />
                        <small>http(s)://www.test.com</small>
                        <span>{{ errors.first('website') }}</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <button type="button" class="btn btn-secondary btn-sm" v-on:click="contact_delete">-</button>
                <button type="button" class="btn btn-primary btn-sm" v-on:click="contact_add">+</button>
                <input class="btn btn-primary" type="submit" name="submit" value="valider">
<!--                <button type="submit" @submit.prevent="$validator.validateAll()" class="btn btn-primary btn-sm" v-on:click="contact_post">Ajouter</button>-->
<!--                <button type="submit" @submit.prevent="$validator.validateAll()" class="btn btn-primary btn-sm">Ajouter</button>-->
            </div>
        </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            // contacts: [{'email': null, 'telephone': null, 'fax': null, 'bp': null, 'website': null}],
            contacts: [],
            country: '',
            city: '',
            cities_list: '',
            city_initiales: '',
            quartier: '',
            quartiers_list: '',
            quartier_initiales: ''
        }
    },
    components: {
        'mycountries': httpVueLoader('js/components/mycountry_list.vue')
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
            // this.contacts_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        contact_post () {
            this.$validator.validateAll().then((success) => {
                if (success == true) {
                    console.log(success);
                    postWithParams('/api/post/contacts',
                                   {
                                       contacts: this.contacts,
                                       id: this.idligne,
                                       typerubrique: this.typerubrique
                                   }
                    ).then((data) => {
                        console.log(data);
                    });
                }
            }).catch((error) => {
                console.log(error);
            // Failed
            });
        },
        contact_add () {
            this.contacts.push({ 'email': null, 'telephone': null, 'fax': null });
        },
        contact_delete () {
            this.contacts.pop();
        }
    }
}
</script>

<style scoped>

</style>
