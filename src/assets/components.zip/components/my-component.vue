<template>
    <div class="hello">Hello {{who}}</div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            who: 'Stefyu'
        }
    }
}
</script>

<style scoped>
    .hello {
        background-color: #ffe;
    }
</style>
