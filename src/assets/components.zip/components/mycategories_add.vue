<template>
    <div>
        <form @submit.prevent="categories_add">
            <div class="form-group">

                <div class="row">
                    <div class="col-lg-12">
                        <br>
                        <div class="card">
                            <div class="card-header">
                                <strong>Ajouter une nouvelle categorie</strong>
                            </div>
                            <div class="card-body">

                                <div class="form-group">
                                    <label>Type de rubrique</label>
                                    <select class="form-control" v-model="categories.typerubrique" @change="categories_master_get()" @blur="handleClick">
                                        <option></option>
                                        <option v-for="item in rubriques_list" :value="item.id">{{item.name}}</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Categories Master</label>
                                    <select v-validate="'required'" class="form-control" v-model="categories.categories_master_id">
                                        <option v-for="cat in categories_master_list"
                                                :value="cat.id"
                                                :key="cat.id"
                                        >
                                            {{cat.name}}
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Nom de la catégorie</label>
                                    <input v-validate="'alpha_num'" class="form-control" type="text" v-model="categories.name" required>
                                </div>
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" type="text" v-model="categories.description" required>
                                    </textarea>
                                </div>
                                <div class="col-6">
                                    <div v-if="!image">
                                        <h6>Selectionner une image</h6>
                                        <input  v-validate="'size:100'" name="img" type="file" @change="onFileChange">
                                    </div>
                                    <div v-else>
                                        <!--        {{image}}-->
                                        <img style="width: 100%" :src="image"/>
                                        <button @click="removeImage">supprimer l'image</button>
                                    </div>
                                </div>

                            </div>
                            <div class="card-footer">
                                <button class="btn btn-sm btn-secondary" type="button" data-dismiss="modal">Fermer</button>
                                <button class="btn btn-sm btn-danger" data-dismiss="modal"  type="submit">Sauvegarder</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            categories: {},
            typerubrique_id: 0,
            categories_master_id: 0,
            categories_master_list: [{ id: '0', name: 'Non defini', typerubrique_id: '1' }, { id: '1', name: 'default', typerubrique_id: '1' }],
            categories_list: '',
            rubriques_list: '',
            rubrique: '',
            image: null,
            image_name: '',
            image_extension: '',
            who: 'Stefyu',
            medias_list: [{ image: '' }]
        }
    },
    created: function () {
        this.type_rubrique();
    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value);
            this.$emit('click');
        },
        handleClick () {
            this.$emit('click');
        },
        type_rubrique () {
            getWithParams('/admin/typerubrique').then(data => {
                this.rubriques_list = data;
                console.log(this.rubriques_list);
            });
        },
        categories_master_get () {
            getWithParams('/api/get/categories_master', { id: this.categories.typerubrique_id }).then(data => {
                const res = JSON.stringify(data);
                this.categories_master_list = JSON.parse(res);
                console.log(this.categories_master_list);
            });
        },
        categories_add () {
            this.$validator.validateAll().then((success) => {
                if (success) {
                    this.categories.icon = this.image;
                    postWithParams('/api/post/categories', this.categories).then(data => {
                        const res = JSON.stringify(data);
                    })
                }
            });
        },
        handleInput2 (value) {
            this.$emit('change', value)
        },
        onFileChange (e) {
            console.log(e);
            var files = e.target.files || e.dataTransfer.files;
            if (!files.length) { return; }
            this.createImage(files[0]);
        },
        createImage (file) {
            console.log(file);
            var a = file.name.split('.');
            this.image_name = file.name;
            this.image_extension = a[1];

            var image = new Image();
            var reader = new FileReader();
            var vm = this;

            reader.onload = (e) => {
                vm.image = e.target.result;
                this.handleInput(vm.image)
            };
            reader.readAsDataURL(file);
        },
        removeImage: function (e) {
            this.image = '';
        },
        reset () {
            this.image = null;
            this.image_name = '';
            this.image_extension = '';
        }
    }
}
</script>

<style scoped>

</style>
