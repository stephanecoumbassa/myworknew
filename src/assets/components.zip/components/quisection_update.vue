<template>
    <div>
            <div v-for="item in sections_list">
                <form @submit.prevent="section_update(item)">
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">Nom de la section</label>
                                <input required class="form-control" v-model="item.name" @input="$emit('blur', sections)" />
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label class="form-text text-dark">Description de la section</label>
                                <textarea required class="form-group" v-model="item.description"></textarea>
                            </div>
                        </div>
                        <div class="col-4">
                            <label class="form-text text-dark">.</label>
                            <button type="submit" class="btn btn-primary">Modifier</button>
                        </div>
                    </div>

                </form>
            </div>

    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            item: [],
            sections: [],
            sections_list: ''
        }
    },
    props: {
        idligne: Number
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.section_get();
            }
        }
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        section_get () {
            getWithParams('/api/get/sections', { id: this.idligne }).then((data) => {
                console.log(data);
                this.sections_list = JSON.parse(data.sections);
                console.log(this.sections_list);
            })
        },
        section_update (item) {
            putWithParams('/api/put/sections', { name: item.name, description: item.description, id: item.id })
                .then(data => {
                    console.log(data)
                });
        }
    }
}
</script>

<style scoped>

</style>
