<template>
    <div>
        <div>
            <form>
                <div class="row">
                    <div class="col-6">
                        <div v-if="medias_list != null">
                            <h6>Fichier Uploade</h6>
                            <img style="width: 100%" :src="'http://127.0.0.1:8000/uploads/articles/'+folder+medias_list.name"/><br>
                            <button type="button" class="btn btn-sm btn-secondary" v-on:click="medias_delete(medias_list.id, medias_list.name)">Supprimer</button>
                        </div>
                    </div>
                    <div class="col-6" v-if="medias_list == null">
                        <h6>Uploader un ficher</h6>
                        <div v-if="!image">
                            <h6>Selectionner une image</h6>
                            <input name="img" type="file" @change="onFileChange">
                        </div>
                        <div v-else>
                            <img style="width: 100%" :src="image"/><br>
                            <button type="button" class="btn btn-sm btn-secondary" @click="removeImage">supprimer l'image</button><br>
                            <button type="button" class="btn btn-success" @click="uploadImage">upload</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            image: '',
            image_name: '',
            image_extension: '',
            who: 'Stefyu',
            medias: '',
            // medias_list: ''
            medias_list: null
        }
    },
    props: {
        typerubrique: Number,
        idligne: Number,
        folder: String
    },
    created: function () {
        // this.links_get();
    },
    model: {
        event: 'change'
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.medias_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('change', value)
        },
        medias_get () {
            getWithParams('/api/get/medias', { id: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                if (data.medias != null) {
                    this.medias_list = JSON.parse(data.medias);
                    this.medias_list = this.medias_list[0];
                } else {
                    this.medias_list = null
                }
            })
        },
        medias_delete (id, filename) {
            deleteWithParams('/api/delete/medias', { data: { id: id, folder: this.folder, filename: filename } }).then((data) => {
                console.log(data);
                this.medias_get();
            })
        },
        onFileChange (e) {
            // console.log(this.image);
            var files = e.target.files || e.dataTransfer.files;
            if (!files.length) { return; }
            this.createImage(files[0]);
        },

        uploadImage () {
            postWithParams('/api/post/medias',
                           {
                               'typerubrique': this.typerubrique,
                               'id': this.idligne,
                               'folder': this.folder,
                               'image': this.image,
                               'image_name': this.image_name,
                               'image_extension': this.image_extension
                           }
            )
                .then(data => {
                    console.log(data);
                    this.medias_get();
                });
        },

        createImage (file) {
            // console.log(this.image);
            var a = file.name.split('.');
            var image = new Image();
            var reader = new FileReader();
            var vm = this;

            vm.image_name = file.name;
            vm.image_extension = a[1];

            reader.onload = (e) => {
                vm.image = e.target.result;
                this.handleInput({ image: vm.image, image_name: vm.image_name, image_extension: vm.image_extension })
            };
            reader.readAsDataURL(file);
        },
        removeImage: function (e) {
            this.image = '';
        },
        update: function (e) {
            if (this.medias_list == null) {
                putWithParams('/api/update/medias', { 'name': this.name,
                                                      'id': this.photo_id,
                                                      'image': this.image,
                                                      'typerubrique': this.typerubrique,
                                                      'image_name': this.image_name,
                                                      'image_extension': this.image_extension }).then(data => {
                                                          const res = JSON.stringify(data);
                                                          console.log(this.categories_initiales);
                                                      });
            }
        }
    }
}
</script>

<style scoped>
    #app {
        text-align: center;
    }
    /*img {*/
    /*    width: 30%;*/
    /*    margin: auto;*/
    /*    display: block;*/
    /*    margin-bottom: 10px;*/
    /*}*/
    /*button {*/

    /*}*/
</style>
