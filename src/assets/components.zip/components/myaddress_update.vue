<template>
    <div>
        <div v-for="address in addresses_list">
            <form @submit.prevent="address_update(address)">
                <div class="row">
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Country</label>
                                    <select class="form-control search-slt" v-model="address.country_id" @input="$emit('blur', addresses)">
                                        <option value="1">RCI</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">City_id</label>
                                    <select required class="form-control search-slt" v-model="address.city_id">
                                        <!--                            <option :value="address.city_id" selected>{{address.city_id}}</option>-->
                                        <option v-for="item in cities_list"
                                                :value="item.id"
                                                :key="item.id">
                                            <!--                                    v-bind:selected="item.id == address.city_id"-->
                                            {{item.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Quartier_id</label>
                                    <select class="form-control search-slt" v-model="address.quartier_id">
                                        <!--                            <option :value="address.quartier_id" selected>{{address.quartier_id}}</option>-->
                                        <option v-for="q in quartiers_list" :value="q.id" :key="q.id">{{q.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">longitude</label>
                                    <input class="form-control" type="text" v-model="address.longitude" />
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">latitude</label>
                                    <input class="form-control" type="text" v-model="address.latitude" />
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">description</label>
                                    <textarea class="form-control" v-model="address.description"></textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Actions</label>
                                    <button type="button" class="btn btn-secondary btn-sm" v-on:click="address_delete(address)">Supprimer</button>
                                    <button type="submit" class="btn btn-primary btn-sm">modifier</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div style="height: 400px; width: 100%">
                            <div class="info" style="height: 15%">
                                <span>latLong: {{ address.latitude }} - {{ address.longitude }}</span><br>
                            </div>
                            <l-map
                                    style="height: 80%; width: 100%"
                                    :zoom="zoom"
                                    :center="center"
                            >
                                @update:zoom="zoomUpdated"
                                @update:center="centerUpdated"
                                @update:bounds="boundsUpdated"
                                <l-tile-layer :url="url"></l-tile-layer>
                                <l-marker :lat-lng="[parseFloat(address.latitude), parseFloat(address.longitude)]" :draggable="true"
                                          v-on:dragend="realMarkerAdd"
                                          :update="[parseFloat(address.latitude), parseFloat(address.longitude)]"
                                          :ready="realMarkerAdd"></l-marker>
                            </l-map>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            addresses: [{ 'country_id': null, 'city_id': null, 'quartier_id': null, 'longlat': null, 'description': null }],
            country: '',
            city: '',
            cities_list: '',
            city_initiales: '',
            quartier: '',
            quartiers_list: '',
            quartier_initiales: '',
            addresses_list: '',
            url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png',
            zoom: 10,
            center: [5.331869883252284, -4.00438422611056],
            bounds: null,
            markerLatLng: [5.331869883252284, -4.00438422611056]
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.cities_get();
        this.quartiers_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.addresses_get();
            }
        }
    },
    methods: {
        realMarkerAdd (e) {
            console.log(this.addresses[0]);
            const i = this.addresses.length - 1;
            this.addresses[i].latitude = e.target._latlng.lat;
            this.addresses[i].longitude = e.target._latlng.lng;
        },
        openPopup: function (event) {
            console.log(event.target);
            event.target.openPopup();
        },
        zoomUpdated (zoom) {
            this.zoom = zoom;
        },
        centerUpdated (center) {
            this.center = center;
        },
        boundsUpdated (bounds) {
            this.bounds = bounds;
        },
        getLongLat () {
            console.log(this.markerLatLng)
        },
        addresses_get () {
            getWithParams('/api/get/addresses', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                // console.log(data);
                // console.log(data.addresses);
                this.addresses_list = JSON.parse(data.addresses);
                console.log(this.addresses_list);
            })
        },
        handleInput (value) {
            this.$emit('blur', value)
        },
        categoriesfilter () {
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        cities_get () {
            getWithParams('/api/get/cities_list', { id: this.country_id }).then(data => {
                const res = JSON.stringify(data);
                this.cities_list = JSON.parse(res);
                this.city_initiales = this.cities_list;
                console.log(this.city_initiales);
                console.log(data);
            });
        },
        quartiers_get () {
            getWithParams('/api/get/quartiers', { id: this.city_id }).then(data => {
                const res = JSON.stringify(data);
                this.quartiers_list = JSON.parse(res);
                this.quartier_initiales = this.quartiers_list;
                console.log(this.quartier_initiales);
            });
        },
        address_update (address) {
            if (confirm('Voulez vous modifier ?')) {
                this.$validator.validateAll().then((success) => {
                    if (success) {
                        console.log(address);
                        putWithParams('/api/put/addresses', address).then((data) => {
                            console.log(data);
                        });
                    }
                });
            }
        },
        address_delete (address) {
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/addresses', { data: { id: address.id } }).then((data) => {
                    console.log(data);
                });
            }
        }
    }
}
</script>

<style scoped>

</style>
