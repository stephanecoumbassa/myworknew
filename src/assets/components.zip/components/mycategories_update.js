Vue.component('mycategoriesupdate', {
    delimiters: ['${', '}'],
    props: {
        typerubrique: Number,
        idcat: Number
    },
    data: function () {
        return {
            count: 0,
            categories_list: '',
            categories_master_list: '',
            categories: '',
            scategories: '',
            categories_initiales: ''
        }
    },
    created: function () {
        this.categories_get();
        this.categories_master_get();
    },
model: {
        event: 'blur'
    },
    watch: {
        idcat: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                // this.contacts_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        categoriesfilter () {
            console.log(this.categories_list);
            console.log(this.categories_master_list);
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        categories_get () {
            getWithParams('/api/get/categories', { id: this.typerubrique }).then(data => {
                const res = JSON.stringify(data);
                this.categories_list = JSON.parse(res);
                this.categories_initiales = this.categories_list;
                console.log(this.categories_initiales);
            });
        },
        categories_master_get () {
            getWithParams('/api/get/categories_master', { id: this.typerubrique }).then(data => {
                const res = JSON.stringify(data);
                this.categories_master_list = JSON.parse(res);
                // console.log(this.categories_master_list);
            });
        }
    },
    template: '  <div> \
     \
                    <div class="form-group">\
                        <label class="form-text text-dark">Categories Parentes</label>\
                        <select class="form-control search-slt" v-on:change="categoriesfilter" v-model="categories" @input="$emit(\'blur\',{cat: categories, scat: idcat})">\
                            <option></option>\
                            <option v-for="cat in categories_master_list"\
                                    :value="cat.id"\
                                    :key="cat.id"\
                                    >${cat.name}</option>\
                        </select>\
                    </div>\
                    \
                    \<div class="form-group">\
                        <label class="form-text text-dark">Categories</label>\
                        <select class="form-control search-slt" v-model="idcat" name="catid" @input="$emit(\'blur\',{cat: categories, scat: idcat})">\
                            <option></option>\
                            <option v-for="scat in categories_list"\
                                    :value="scat.id"\
                                    :key="scat.id">${scat.name}</option>\
                        </select>\
                    </div>\
                </div>\
            '
});
