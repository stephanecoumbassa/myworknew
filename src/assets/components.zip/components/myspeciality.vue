<template>
    <div>
        <div class="row">
            <div v-if="specialities_list_item.length >=1" v-for="item in specialities_list_item" class="col-3">
                <div class="card">
                    <div class="card-body">
                            <select required class="form-control" v-model="item.specialityid" readonly>
                                <option :value="item.specialityid"
                                        :key="item.specialityid"
                                >{{item.specialityname}}</option>
                            </select>

                            <select required class="form-control" v-model="item.value_id">
                                <option v-for="auto in JSON.parse(JSON.stringify(item.autocomplete))"
                                        :value="auto.id"
                                        :key="auto.id"
                                >{{auto.name}}</option>
                            </select>
                    </div>
                    <div class="card-footer">
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="speciality_delete(item)">Supprimer</button>
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="speciality_update(item)">Modifier</button>
                    </div>
                </div>
            </div>
        </div>
        <div v-for="item in specialities">
            <div class="row">
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Champs</label>
                        <select required class="form-control search-slt" v-model="item.id"
                         @change="categoriesfilter(item.id)" @input="$emit('blur', specialities)">
                            <option></option>
                            <option v-for="sp in specialities_list"
                                    :value="sp.id"
                                    :key="sp.id"
                            >{{sp.name}}</option>
                        </select>
                    </div>
                </div>
                <div class="col-8">
                    <div class="form-group">
                        <label class="form-text text-dark">Autocomplete</label>
                        <v-select aria-required="true" required multiple label="name" v-model="item.value" :options="autocomplete_list" />
                    </div>
                </div>
            </div>
        </div>

        <button type="button" class="btn btn-primary btn-sm" v-on:click="specialities_create">Ajouter dans la base</button>
        <button type="button" class="btn btn-secondary btn-sm" v-on:click="specialities_delete">-</button>
        <button type="button" class="btn btn-primary btn-sm" v-on:click="specialities_add">+</button>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            item: [],
            update_status: false,
            // specialities: [{id:'', value: '', value2: [{'label': null, 'id': null}]}],
            // specialities: [{}],
            specialities: [{}],
            specialities_list: '',
            specialities_list_item: [],
            autocomplete_list: [],
            autocomplete_initiales: '',
            valeur_json: []
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.speciality_get();
            }
        }
    },
    created: function () {
        this.specialities_get();
        this.specialities_autocomplete_get();
    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        setSelected (value) {
            this.valeur_json.push(value);
        },
        categoriesfilter (id) {
            this.autocomplete_list = this.autocomplete_initiales;
            let autos = this.autocomplete_list.filter((auto) => {
                return auto.speciality_id === String(id);
            });
            console.log(autos);
            this.autocomplete_list = autos;
        },
        jsonifier (value) {
            return JSON.parse(JSON.stringify(value));
        },
        speciality_get () {
            getWithParams('/api/get/specialities', { id: this.idligne }).then((data) => {
                console.log(data);
                this.specialities_list_item = JSON.parse(data.specialities);
                console.log(this.specialities_list_item);
            })
        },
        specialities_get () {
            getWithParams('/api/get/specialities_type').then(data => {
                const res = JSON.stringify(data);
                this.specialities_list = JSON.parse(res);
                console.log(this.specialities_list);
            });
        },
        specialities_autocomplete_get () {
            getWithParams('/api/get/specialities_autocomplete').then(data => {
                const res = JSON.stringify(data);
                this.autocomplete_list = JSON.parse(res);
                this.autocomplete_initiales = JSON.parse(res);
                console.log(this.autocomplete_list);
            });
        },
        specialities_add () {
            this.specialities.push({ 'type': null, 'name': null });
        },
        specialities_create () {
            valjson = [];
            for (let i = 0; i < this.specialities.length; i++) {
                for (let j = 0; j < this.specialities[i].value.length; j++) {
                    valjson.push(this.specialities[i].value[j]);
                }
            }
            this.update_status = true;
            postWithParams('/api/post/specialities', { valjson: JSON.stringify(valjson), id: this.idligne }).then(data => {
                console.log(data);
                this.speciality_get();
            });
        },
        speciality_update (speciality) {
            putWithParams('/api/put/specialities', speciality).then((data) => {
                console.log(data);
                this.speciality_get();
            });
        },
        speciality_delete (speciality) {
            console.log(speciality.id);
            deleteWithParams('/api/delete/specialities', { data: { id: speciality.id } }).then((data) => {
                console.log(data);
                this.speciality_get();
            });
        },
        specialities_delete () {
            this.specialities.pop();
        },
        update (speciality) {
            this.specialities = [speciality];
            this.update_status = true;
            console.log(this.specialities);
        }
    }
}
</script>

<style scoped>

</style>
