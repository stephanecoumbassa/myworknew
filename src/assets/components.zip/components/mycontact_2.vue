<template>
    <div>
        <div class="row">
            <div v-if="contacts_list.length >=1" v-for="item in contacts_list" class="col-4">
                <div class="card">
                    <div class="card-body">
                        {{item.email}}<br>
                        +{{item.indicatif}} {{item.telephone}}<br>
                        {{item.fax}}<br>
                        {{item.bp}}<br>
                        {{item.website}}<br>
                    </div>
                    <div class="card-footer">
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="contacts_delete(item)">Supprimer</button>
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="update(item)">Modifier</button>
                    </div>
                </div>
            </div>
        </div>

        <form @submit.prevent="contact_post" v-if="contacts.length >=1" >
            <div v-for="item in contacts">

                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Email</label>
                            <input class="form-control" v-validate="'required|email'" name="email" type="email" v-model="item.email"/>
                            <span>{{ errors.first('email') }}</span>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label class="form-text text-dark">Indicatif</label>
                            <select name="indicatif" v-model="item.indicatif" v-on:change="handleInput" class="form-control">
                                <option></option>
                                <option v-for="item in countries" :value="item.indicatif">{{item.name_fr}} (+{{item.indicatif}})</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-5">
                        <label class="form-text text-dark">Telephone</label>
                        <input required placeholder="numero" name="telephone" type="number" v-model="item.telephone" class="form-control" />
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Fax</label>
                            <input class="form-control" type="text" v-model="item.fax" />
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">BP</label>
                            <input class="form-control" type="text" v-model="item.bp" />
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">website</label>
                            <input class="form-control" v-validate="{url: {require_protocol: true }}" name="website" type=url v-model="item.website" />
                            <small>http(s)://www.test.com</small>
                            <span>{{ errors.first('website') }}</span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <input class="btn btn-secondary" type="button" name="submit" value="fermer" v-on:click="reset">
                            <input v-if="!update_status" class="btn btn-primary" type="submit" name="submit" value="valider">
                            <input v-if="update_status" class="btn btn-primary" type="button" name="submit" value="modifier" v-on:click="contact_update(item)">
                        </div>
                    </div>

                </div>
            </div>
        </form>
        <div class="row">
                <div class="col-12">
                    <button v-if="!update_status" type="button" class="btn btn-sm btn-secondary" v-on:click="contact_delete">-</button>
                    <button v-if="!update_status" type="button" class="btn btn-sm btn-secondary" v-on:click="contact_add">+</button>
                </div>
            </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            who: 'world',
            contacts: [],
            update_status: false,
            count: 0,
            countries: [],
            country: this.code,
            contacts_list: []
        }
    },
    created: function () {
        this.countries_get();
        this.handleInput();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number,
        code: {
            type: Number,
            default: 225
        }
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.contacts_get();
            // this.contacts_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        reset () {
            this.contacts = [];
            this.update_status = false;
        },
        contact_post () {
            this.$validator.validateAll().then((success) => {
                if (success == true) {
                    if (confirm('Voulez vous ajouter ?')) {
                        postWithParams('/api/post/contacts',
                                       { contacts: this.contacts, id: this.idligne, typerubrique: this.typerubrique }
                        ).then((data) => {
                            this.contacts_get();
                            this.contacts = [];
                        });
                    }
                }
            }).catch((error) => {
                console.log(error);
            });
        },
        contact_add () {
            this.contacts.push({ 'email': null, 'telephone': null, 'fax': null });
        },
        contact_delete () {
            this.contacts.pop();
        },
        countries_get () {
            getWithParams('/api/get/countries').then((data) => {
                this.countries = data;
                console.log(this.countries);
            });
        },
        contacts_get () {
            getWithParams('/api/get/contacts', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                this.contacts_list = JSON.parse(data.contacts);
                console.log(this.contacts_list);
            })
        },
        update (contact) {
            this.contacts = [contact];
            this.update_status = true;
            console.log(this.contacts);
        },
        contact_update (contact) {
            if (confirm('Voulez vous modifier ?')) { this.update_status = false; }
            putWithParams('/api/put/contacts', contact).then((data) => {
                console.log(data);
                this.contacts_get();
                this.contacts = [];
            });
        },
        contacts_delete (contact) {
            console.log(contact.id);
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/contacts', { data: { id: contact.id } }).then((data) => {
                    console.log(data);
                    this.contacts_get();
                    this.contacts = [];
                });
            }
        }
    }
}
</script>

<style>

</style>
