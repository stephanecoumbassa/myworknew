<template>
    <div>
            <div class="row">
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Specialité</label>
                        <select required class="form-control search-slt" v-model="speciality_id"  @input="$emit('blur', autocomplete)">
                            <option></option>
                            <option v-for="sp in specialities_list"
                                    :value="sp.id"
                                    :key="sp.id"
                            >{{sp.name}}</option>
                        </select>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Nom</label>
                        <input class="form-control" name=""  v-model="autocomplete"/>
                    </div>
                </div>
                <div class="col-4">
                    <label class="form-text text-dark">.</label>
                    <button type="button" class="btn btn-primary" v-on:click="autocomplete_create">Creer une autocompletion</button>
                </div>
            </div>

    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            item: [],
            speciality_id: '',
            autocomplete: '',
            specialities_list: ''
        }
    },
    created: function () {
        this.specialities_get();
    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        setSelected (value) {
            // console.log(value);
            this.valeur_json.push(value);
            console.log(this.valeur_json)
        },
        specialities_get () {
            getWithParams('/api/get/specialities_type').then(data => {
                const res = JSON.stringify(data);
                this.specialities_list = JSON.parse(res);
                console.log(this.specialities_list);
            });
        },
        autocomplete_create () {
            postWithParams('/api/post/autocomplete_type', { name: this.autocomplete, speciality_id: this.speciality_id }).then(data => {
                console.log(data);
            });
        }
    }
}
</script>

<style scoped>

</style>
