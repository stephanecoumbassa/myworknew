<template>
    <div>
        <form>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-text text-dark">Type de lien</label>
                        <select v-validate="'required'" required class="form-control search-slt" v-model="type">
                            <option></option>
                            <option v-for="item in medias_type"
                                    :value="item.id"
                                    :key="item.id"
                            >{{item.name}}</option>
                        </select>
                    </div>
                </div>

                <div class="col-12">
                    <div v-if="show_crop">
                        <croppa v-model="myCroppa"
                                :width="width"
                                :height="height"
                                :quality="quality"
                                initial-size="contain"
                                :prevent-white-space="true"
                                :file-size-limit="1024000"
                                :show-remove-button="false"
                                @file-type-mismatch="onFileTypeMismatch"
                                @file-size-exceed="onFileSizeExceed"
                        ></croppa><br>
                        <button type="button" @click="myCroppa.remove()">Supprimer</button>
                        <button type="button" @click="uploadCroppedImage('image/jpeg', 0.5)">Recadrer</button>
                    </div>
                    <div v-if="!show_crop">
<!--                        <img :src="dataUrl" style="max-width: 1200px; width: 100%;"><br>-->
                        <img :src="dataUrl" :width="width" :height="height"><br>
                        <button type="button" @click="show_crop = true">Revenir à l'upload</button>
                    </div>
                </div>

                <div class="col-12">
                    <button v-if="!status_upload" type="button" v-on:click="reset" class="btn btn-sm btn-secondary">Reset</button>
                    <button v-if="!status_upload" type="button" class="btn btn-sm btn-primary" v-on:click="medias_add">Ajouter</button>
                    <button v-if="status_upload" type="button" class="btn btn-sm btn-secondary">Upload OK</button>
                </div>

            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            image: null,
            type: [],
            image_name: '',
            image_extension: 'jpg',
            who: 'Stefyu',
            medias_list: [{ image: '' }],
            medias_type: [],
            show_crop: true,
            myCroppa: {},
            dataUrl: '',
            status_upload: false
        }
    },
    props: {
        typerubrique: Number,
        idligne: Number,
        folder: String,
        height: {
            type: Number,
            default: 250
        },
        width: {
            type: Number,
            default: 250
        },
        quality: {
            type: Number,
            default: 1
        }
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) { }
        }
    },
    created: function () {
        this.medias_get();
    },
    model: {
        event: 'change'
    },
    methods: {
        handleInput (value) {
            this.$emit('change', value)
        },
        medias_get () {
            getWithParams('/api/get/medias_type').then(data => {
                const res = JSON.stringify(data);
                this.medias_type = JSON.parse(res);
            });
        },
        removeImage: function (e) {
            this.image = '';
        },
        reset () {
            this.image = null;
            this.image_name = '';
            this.image_extension = '';
        },
        medias_add () {
            if (confirm('Voulez vous ajouter ?')) {
                postWithParams('/api/post/medias_one',
                               {
                                   'typerubrique': this.typerubrique,
                                   'type': this.type,
                                   'id': this.idligne,
                                   'folder': this.folder,
                                   'image_extension': this.image_extension,
                                   'image': this.image,
                                   'image_name': this.image_name
                               }
                )
                    .then(data => {
                        console.log(data);
                        if (data.status == 1) { this.status_upload = true }
                    });
            }
        },
        medias_delete () {
            this.medias_list.pop();
        },
        uploadCroppedImage () {
            this.dataUrl = this.myCroppa.generateDataUrl('image/jpeg');
            this.image = this.myCroppa.generateDataUrl('image/jpeg');
            this.show_crop = false;
        },
        download (type, compressionRate) {
            this.myCroppa.generateBlob((blob) => {
                var url = URL.createObjectURL(blob);
                console.log(blob);
                console.log(url);
                var a = document.createElement('a');
                a.download = 'filename';
                a.href = url;
                a.click();
                URL.revokeObjectURL(url);
            }, type, compressionRate)
        },
        onFileTypeMismatch (file) {
            alert('Type de fichier invalide. Veuillez choisir un fichier jpeg or png.')
        },
        onFileSizeExceed (file) {
            alert('Taille du fichier depassé. SVP Veuillez choisir un fichier plus petit que 1000kb.')
        }
    }
}
</script>

<style scoped>
    canvas{
        width: 100%;
    }
</style>
