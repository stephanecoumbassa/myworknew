<template>
    <div>
        <form @submit.prevent="address_post">
            <div v-for="address in addresses">
                <div class="row">
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Country</label>
                                    <select v-validate="'required'" required class="form-control search-slt" v-model="address.country_id" @input="$emit('blur', addresses)">
                                        <option value="1">RCI</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">City_id</label>
                                    <select v-validate="'required'" required class="form-control search-slt" v-model="address.city_id" v-on:change="quartiers_get(address.city_id) ">
                                        <!--<option :value="address.city_id" selected>{{address.city_id}}</option>-->
                                        <option v-for="item in cities_list"
                                                :value="item.id"
                                                :key="item.id">
                                            <!--v-bind:selected="item.id == address.city_id"-->
                                            {{item.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">Quartier_id</label>
                                    <select class="form-control search-slt" v-model="address.quartier_id">
                                        <!--<option :value="address.quartier_id" selected>{{address.quartier_id}}</option>-->
                                        <option v-for="q in quartiers_list" :value="q.id">{{q.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-text text-dark">description</label>
                                    <textarea class="form-control" v-model="address.description"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div style="height: 400px; width: 100%">
                            <div class="info" style="height: 15%">
                                <span>latLong: {{ address.latitude }} - {{ address.longitude }}</span><br>
                            </div>
                            <l-map
                                    style="height: 80%; width: 100%"
                                    :zoom="zoom"
                                    :center="center"
                                    @update:zoom="zoomUpdated"
                                    @update:center="centerUpdated"
                                    @update:bounds="boundsUpdated"
                            >
                                <l-tile-layer :url="url"></l-tile-layer>
                                <l-marker :lat-lng="markerLatLng" :draggable="true"
                                          v-on:dragend="realMarkerAdd"
                                          :update="markerLatLng"
                                          :ready="realMarkerAdd"></l-marker>
                            </l-map>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-lg-4">
                <button type="button" class="btn btn-secondary btn-sm" v-on:click="address_delete">-</button>
                <button type="button" class="btn btn-primary btn-sm" v-on:click="address_add">+</button>
<!--                <button type="submit" class="btn btn-primary btn-sm" v-on:click="address_post">Ajouter</button>-->
                <button type="submit" class="btn btn-primary btn-sm">Ajouter</button>
            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            addresses: [],
            country: '',
            city: '',
            city_id: '',
            cities_list: '',
            city_initiales: '',
            quartier: '',
            quartiers_list: '',
            quartier_initiales: '',
            addresses_list: '',
            url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png',
            zoom: 10,
            center: [5.331869883252284, -4.00438422611056],
            bounds: null,
            markerLatLng: [5.331869883252284, -4.00438422611056]
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.cities_get();
        // this.quartiers_get();
    },
    model: {
        // event: 'blur'
    },
    mounted: function () {
        // setTimeout(function() { window.dispatchEvent(new Event('resize')) }, 250);
        // this.$refs.map.mapObject._onResize();
    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.addresses_get();
            }
        }
    },
    methods: {
        realMarkerAdd (e) {
            const i = this.addresses.length - 1;
            this.addresses[i].latitude = e.target._latlng.lat;
            this.addresses[i].longitude = e.target._latlng.lng;
            console.log(this.addresses)
        },
        openPopup: function (event) {
            console.log(event.target);
            event.target.openPopup();
        },
        zoomUpdated (zoom) {
            this.zoom = zoom;
        },
        centerUpdated (center) {
            this.center = center;
        },
        boundsUpdated (bounds) {
            this.bounds = bounds;
        },
        getLongLat () {
            console.log(this.markerLatLng)
        },
        addresses_get () {
            getWithParams('/api/get/addresses', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                this.addresses_list = JSON.parse(data.addresses);
                console.log(this.addresses_list);
            })
        },
        handleInput (value) {
            this.$emit('blur', value)
        },
        categoriesfilter () {
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        cities_get () {
            getWithParams('/api/get/cities_list', { id: this.country_id }).then(data => {
                const res = JSON.stringify(data);
                this.cities_list = JSON.parse(res);
                this.city_initiales = this.cities_list;
                console.log(this.city_initiales);
                console.log(data);
            });
        },
        quartiers_get (id) {
            getWithParams('/api/get/quartiers', { id: id }).then(data => {
                const res = JSON.stringify(data);
                this.quartiers_list = JSON.parse(res);
                this.quartier_initiales = this.quartiers_list;
                console.log(this.quartier_initiales);
            });
        },
        address_post () {
            this.$validator.validateAll().then((success) => {
                if (success) {
                    postWithParams('/api/post/addresses', {
                        addresses: this.addresses,
                        id: this.idligne,
                        typerubrique: this.typerubrique
                    }).then((data) => {
                        console.log(data);
                    });
                }
            });
        },
        quartierfilter () {
            this.quartiers_list = this.quartier_initiales;
            let quarts = this.quartiers_list.filter((quart) => {
                return quart.city_id === String(this.quartier);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        address_add () {
            this.addresses.push({ 'country_id': null, 'city_id': null, 'latitude': null, 'longitude': null, 'description': null });
        },
        address_delete () {
            this.addresses.pop();
        }
    }
}
</script>

<style scoped>

</style>
