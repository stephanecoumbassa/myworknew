<template>
    <div>
        <form @submit.prevent="categories_master_add()">
            <div class="form-group">

                <div class="row">
                    <div class="col-lg-12">
                        <br>
                        <div class="card">
                            <div class="card-header">
                                <strong>Ajouter une nouvelle categorie parente</strong>
                            </div>
                            <div class="card-body">

<!--                                <div class="form-group">-->
<!--                                    <label>Type de rubrique</label>-->
<!--                                    <select class="form-control" v-model="categories.typerubrique">-->
<!--                                        <option></option>-->
<!--                                        <option v-for="item in rubriques_list" :value="item.id">{{item.name}}</option>-->
<!--                                    </select>-->
<!--                                </div>-->
                                <div class="form-group">
                                    <label>Nom de la catégorie</label>
                                    <input class="form-control" type="text" v-model="categories.name" required>
                                </div>
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" type="text" v-model="categories.description" required>
                                    </textarea>
                                </div>
                                <div class="row">
<!--                                    <div class="col-4">-->
<!--                                        <img style="width: 50%" :src="'../../uploads/articles/categories/'+categories.icon"/>-->
<!--                                    </div>-->
                                    <div class="col-8">
                                        <img style="width: 100px; height: 100px" :src="image2"/>
                                        <div v-if="!image">
                                            <h6>Selectionner une image</h6>
                                            <input  v-validate="'size:100'" name="img" type="file" @change="onFileChange">
                                        </div>
                                        <div v-else>
                                            <!--        {{image}}-->
                                            <img style="width: 100px; height: 100px" :src="image"/>
                                            <button @click="removeImage">supprimer l'image</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="card-footer">
                                <button class="btn btn-sm btn-secondary" type="button" data-dismiss="modal">Fermer</button>
                                <button class="btn btn-sm btn-danger" data-dismiss="modal" v-on:click="categories_master_update" type="submit">Sauvegarder</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            // categories: {},
            typerubrique_id: 0,
            categories_master_id: 0,
            categories_list: '',
            rubriques_list: '',
            rubrique: '',
            image: null,
            image2: null,
            image_name: '',
            image_extension: '',
            who: 'Stefyu',
            medias_list: [{ image: '' }]
        }
    },
    props: {
        categories: Object
    },
    watch: {
        categories: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                // this.image = '../../uploads/articles/categories/'+this.categories.icon;
                this.image2 = '../../uploads/categories/' + this.categories.icon;
            }
        }
    },
    created: function () {
        this.type_rubrique();
    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value);
            this.$emit('click');
        },
        categories_get () {
            getWithParams('/api/get/contacts', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                this.contacts_list = JSON.parse(data.contacts);
                console.log(this.contacts_list);
            })
        },
        handleClick () {
            this.$emit('click');
        },
        type_rubrique () {
            getWithParams('/admin/typerubrique').then(data => {
                this.rubriques_list = data;
                console.log(this.rubriques_list);
            });
        },
        categories_master_update () {
            this.categories.image = this.image;
            this.categories.image_name = this.image_name;
            this.categories.image_extension = this.image_extension;
            putWithParams('/api/put/categories_master', this.categories).then(data => {
                const res = JSON.stringify(data);
                console.log(data);
            })
        },
        handleInput2 (value) {
            this.$emit('change', value)
        },
        onFileChange (e) {
            console.log(e);
            var files = e.target.files || e.dataTransfer.files;
            if (!files.length) { return; }
            this.createImage(files[0]);
        },
        createImage (file) {
            console.log(file);
            var a = file.name.split('.');
            this.image_name = file.name;
            this.image_extension = a[1];

            var image = new Image();
            var reader = new FileReader();
            var vm = this;

            reader.onload = (e) => {
                vm.image = e.target.result;
                this.handleInput(vm.image)
            };
            reader.readAsDataURL(file);
        },
        removeImage: function (e) {
            this.image = '';
        },
        reset () {
            this.image = null;
            this.image_name = '';
            this.image_extension = '';
        }
    }
}
</script>

<style scoped>

</style>
