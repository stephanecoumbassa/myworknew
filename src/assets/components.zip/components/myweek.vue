<template>
    <div>
        <form>
            <div class="row">
                <div class="col-4">
                    <div class="form-group form-check">
                        <input type="checkbox" :checked="check_true(week.j1)" class="form-check-input" :value="week.j1" v-model="week.j1">
                        <label class="form-check-label">Lundi | Fermer / Ouvert</label>
                    </div>
                </div>
                <div class="col-4">
                    <!--                <input v-if="week.j1 != 0" class="form-control" type="time" v-model="week.j1_start" @input="$emit('blur', week)">-->
                    <input class="form-control" type="time" v-model="week.j1_start" @input="$emit('blur', week)">
                </div>
                <div class="col-4">
                    <input class="form-control" type="time" v-model="week.j1_end">
                    <!--                <input v-if="week.j1 != 0" class="form-control" type="time" v-model="week.j1_end">-->
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <div class="form-group form-check">
                        <input type="checkbox" :checked="check_true(week.j2)" class="form-check-input" v-model="week.j2">
                        <label class="form-check-label">Mardi | Fermer / Ouvert</label>
                    </div>
                </div>
                <div class="col-4">
                    <input v-if="week.j2" class="form-control" type="time" v-model="week.j2_start" @input="$emit('blur', week)">
                </div>
                <div class="col-4">
                    <input v-if="week.j2" class="form-control" type="time" v-model="week.j2_end">
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <div class="form-group form-check">
                        <input type="checkbox" :checked="check_true(week.j3)" class="form-check-input" v-model="week.j3">
                        <label class="form-check-label">Mercredi | Fermer / Ouvert</label>
                    </div>
                </div>
                <div class="col-4">
                    <input v-if="week.j3" class="form-control" type="time" v-model="week.j3_start" @input="$emit('blur', week)">
                </div>
                <div class="col-4">
                    <input v-if="week.j3" class="form-control" type="time" v-model="week.j3_end">
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <div class="form-group form-check">
                        <input type="checkbox" :checked="check_true(week.j4)" class="form-check-input" v-model="week.j4">
                        <label class="form-check-label">Jeudi | Fermer / Ouvert</label>
                    </div>
                </div>
                <div class="col-4">
                    <input v-if="week.j4" class="form-control" type="time" v-model="week.j4_start">
                </div>
                <div class="col-4">
                    <input v-if="week.j4" class="form-control" type="time" v-model="week.j4_end">
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <div class="form-group form-check">
                        <input type="checkbox" :checked="check_true(week.j5)" class="form-check-input" v-model="week.j5">
                        <label class="form-check-label">Vendredi | Fermer / Ouvert</label>
                    </div>
                </div>
                <div class="col-4">
                    <input v-if="week.j5" class="form-control" type="time" v-model="week.j5_start">
                </div>
                <div class="col-4">
                    <input v-if="week.j5" class="form-control" type="time" v-model="week.j5_end">
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <div class="form-group form-check">
                        <input type="checkbox"  class="form-check-input" v-model="week.j6">
                        <label class="form-check-label">Samedi | Fermer / Ouvert</label>
                    </div>
                </div>
                <div class="col-4">
                    <input v-if="week.j6" class="form-control" type="time" v-model="week.j6_start">
                </div>
                <div class="col-4">
                    <input v-if="week.j6" class="form-control" type="time" v-model="week.j6_end">
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" v-model="week.j7">
                        <label class="form-check-label">Dimanche | Fermer / Ouvert</label>
                    </div>
                </div>
                <div class="col-4">
                    <input v-if="week.j7" class="form-control" type="time" v-model="week.j7_start">
                </div>
                <div class="col-4">
                    <input v-if="week.j7" class="form-control" type="time" v-model="week.j7_end">
                </div>
            </div>
            <button v-if="check_status" type="button" class="btn btn-secondary btn-sm" v-on:click="week_delete(week.PJ_ID)">supprimer</button>
            <button v-if="!check_status" type="button" class="btn btn-primary btn-sm" v-on:click="week_post(week)">Creer</button>
            <button v-if="check_status" type="button" class="btn btn-primary btn-sm" v-on:click="week_update(week)">Modifier</button>
        </form>
    </div>

</template>

<script>
module.exports = {
    data: function () {
        return {
            week: { PJ_ID: '1',
                    id: '1',
                    id_ligne: '1',
                    j1: '1',
                    j1_end: '18:00',
                    j1_start: '06:00',
                    j2: '1',
                    j2_end: '18:00',
                    j2_start: '06:00',
                    j3: '1',
                    j3_end: '18:00',
                    j3_start: '06:00',
                    j4: '1',
                    j4_end: '18:00',
                    j4_start: '06:00',
                    j5: '1',
                    j5_end: '18:00',
                    j5_start: '06:00',
                    j6: '0',
                    j6_end: '00:00',
                    j6_start: '00:00',
                    j7: '0',
                    j7_end: '00:00',
                    j7_start: '00:00'
            },
            weeks_list: '',
            check_status: false
        }
    },
    props: {
        idligne: Number
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.week_get();
            }
        }
    },
    created: function () {
        // this.week_get();
        console.log(this.week.length)
    },
    model: {
        event: 'blur'
    },
    methods: {
        check_true (value) {
            if (parseInt(value) == 1) {
                return true;
            } else {
                return false;
            }
        },
        check_true_reverse (value) {
            if (value == true) {
                return 1;
            } else {
                return 0;
            }
        },
        hmsToSecondsOnly (str) {
            var p = str.split(':'),
                s = 0, m = 1;
            while (p.length > 0) {
                s += m * parseInt(p.pop(), 10);
                m *= 60;
            }
            return s;
        },
        handleInput (value) {
            this.$emit('blur', value)
        },
        week_post (week) {
            week.j1 = week.j1 | 0;
            week.j2 = week.j2 | 0;
            week.j3 = week.j3 | 0;
            week.j4 = week.j4 | 0;
            week.j5 = week.j5 | 0;
            week.j6 = week.j6 | 0;
            week.j7 = week.j7 | 0;
            console.log(this.week);
            // console.log(this.hmsToSecondsOnly(this.week.j6_start);
            postWithParams('/api/post/horaires', { week: JSON.stringify(week), id: this.idligne }).then((data) => {
                console.log(data);
                this.check_status = true;
            });
        },
        week_get () {
            getWithParams('/api/get/horaires', { id: this.idligne }).then((data) => {
                console.log(data);
                this.week = data;
                console.log(this.week);
                if (!(this.week == false)) {
                    this.check_status = true;
                    this.week.j1 = this.check_true(this.week.j1);
                    this.week.j2 = this.check_true(this.week.j2);
                    this.week.j3 = this.check_true(this.week.j3);
                    this.week.j4 = this.check_true(this.week.j4);
                    this.week.j5 = this.check_true(this.week.j5);
                    this.week.j6 = this.check_true(this.week.j6);
                    this.week.j7 = this.check_true(this.week.j7);
                    console.log(this.week);
                } else {
                    this.week = { PJ_ID: '1',
                                  id: '1',
                                  id_ligne: '1',
                                  j1: '1',
                                  j1_end: '18:00',
                                  j1_start: '06:00',
                                  j2: '1',
                                  j2_end: '18:00',
                                  j2_start: '06:00',
                                  j3: '1',
                                  j3_end: '18:00',
                                  j3_start: '06:00',
                                  j4: '1',
                                  j4_end: '18:00',
                                  j4_start: '06:00',
                                  j5: '1',
                                  j5_end: '18:00',
                                  j5_start: '06:00',
                                  j6: '0',
                                  j6_end: '00:00',
                                  j6_start: '00:00',
                                  j7: '0',
                                  j7_end: '00:00',
                                  j7_start: '00:00'
                    };
                }
            })
        },
        week_update (week) {
            this.week.j1 = this.check_true_reverse(this.week.j1);
            this.week.j2 = this.check_true_reverse(this.week.j2);
            this.week.j3 = this.check_true_reverse(this.week.j3);
            this.week.j4 = this.check_true_reverse(this.week.j4);
            this.week.j5 = this.check_true_reverse(this.week.j5);
            this.week.j6 = this.check_true_reverse(this.week.j6);
            this.week.j7 = this.check_true_reverse(this.week.j7);
            putWithParams('/api/put/horaires', { week: JSON.stringify(week), id: this.idligne }).then((data) => {
                console.log(data);
            });
        },
        week_delete (id) {
            deleteWithParams('/api/delete/horaires', { data: { id: id } }).then((data) => {
                console.log(data);
                this.check_status = false;
            });
        }
    }
}
</script>

<style scoped>

</style>
