<template>
    <div>
        <form>
            <div v-for="q in workers">
                <div class="row">
                    <div class="col-4">
                        <label class="form-text text-dark">ID dirigeant</label>
                        <v-select label="fullname" v-model="q.id_qui" :options="workers_list"></v-select>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Ordre Hierachique</label>
                            <input class="form-control" type="text"  v-model="q.ordre" @input="$emit('blur', workers)">
                        </div>
                    </div>
                    <div class="col-4">
                        <label>Actions</label><br>
                        <button type="button" class="btn btn-secondary btn-sm" v-on:click="worker_delete(q)">supprimer</button>
                        <button type="button" class="btn btn-primary btn-sm" v-on:click="worker_update(q)">modifier</button>
                    </div>
                </div>

            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            selected: '',
            count: 0,
            // workers: [{'qui_id': null, 'order': null}],
            country: '',
            workers_list: [],
            workers: {}
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        this.workers_get();
        this.worker_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.worker_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        // qui_add(){
        //     this.qui.push({'qui_id': null, 'order': null});
        //     console.log(this.qui);
        // },
        // qui_delete(){
        //     this.qui.pop();
        // },
        // qui_get(){
        //     getWithParams("/admin/qui_auto").then(data => {
        //         const res = JSON.stringify(data);
        //         this.qui_list = JSON.parse(res);
        //         this.qui_initiales = this.qui_list;
        //         console.log(this.qui_initiales);
        //     });
        // },
        workers_get () {
            getWithParams('/api/get/qui').then((data) => {
                console.log(data);
                this.workers_list = data;
                console.log(this.workers_list);
            })
        },
        worker_get () {
            getWithParams('/api/get/workers', { id: this.idligne }).then((data) => {
                console.log(data);
                this.workers = JSON.parse(data.workers);
                console.log(this.workers);
            })
        },
        worker_update (worker) {
            putWithParams('/api/put/workers', { id: worker.id, ordre: worker.ordre, id_qui: worker.id_qui.id }).then((data) => {
                console.log(data);
            });
        },
        worker_delete (worker) {
            console.log(worker.id);
            deleteWithParams('/api/delete/workers', { data: { id: worker.id } }).then((data) => {
                console.log(data);
            });
        }
    }
}
</script>

<style scoped>

</style>
