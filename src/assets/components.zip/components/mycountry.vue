<template>
    <div>
        <form @submit.prevent="country_post">
            <div v-for="item in countries">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Pays</label>
                            <input v-validate="'required'" required class="form-control" type="text" v-model="item.name" />
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">code</label>
                            <input v-validate="'required'" required class="form-control" type="text" v-model="item.code" />
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-text text-dark">Indicatif</label>
                            <input v-validate="'required'" class="form-control" type="text" v-model="item.indicatif" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <button type="button" class="btn btn-secondary btn-sm" v-on:click="country_delete">-</button>
                <button type="button" class="btn btn-primary btn-sm" v-on:click="country_add">+</button>
                <button type="submit" class="btn btn-primary btn-sm">Ajouter</button>
            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            country: '',
            countries: [{}],
            city: '',
            cities_list: '',
            city_initiales: '',
            quartier: '',
            quartiers_list: '',
            quartier_initiales: '',
            addresses_list: ''
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {
        // this.cities_get();
        // this.quartiers_get();
    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
            // this.addresses_get();
            }
        }
    },
    methods: {
        addresses_get () {
            getWithParams('/api/get/addresses', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                this.addresses_list = JSON.parse(data.addresses);
                console.log(this.addresses_list);
            })
        },
        handleInput (value) {
            this.$emit('blur', value)
        },
        categoriesfilter () {
            this.categories_list = this.categories_initiales;
            let cats = this.categories_list.filter((cat) => {
                return cat.categories_master_id === String(this.categories);
            });
            console.log(cats);
            this.categories_list = cats;
        },
        cities_get () {
            getWithParams('/api/get/cities', { id: this.country_id }).then(data => {
                const res = JSON.stringify(data);
                this.cities_list = JSON.parse(res);
                this.city_initiales = this.cities_list;
                console.log(this.city_initiales);
                console.log(data);
            });
        },
        quartiers_get () {
            getWithParams('/api/get/quartiers', { id: this.city_id }).then(data => {
                const res = JSON.stringify(data);
                this.quartiers_list = JSON.parse(res);
                this.quartier_initiales = this.quartiers_list;
                console.log(this.quartier_initiales);
            });
        },
        country_post () {
            postWithParams('/api/post/countries', { countries: this.countries }).then((data) => {
                console.log(data);
            });
        },
        country_add () {
            this.countries.push({ 'name': null, 'code': null, 'indicatif': null });
        },
        country_delete () {
            this.countries.pop();
        }
    }
}
</script>

<style scoped>

</style>
