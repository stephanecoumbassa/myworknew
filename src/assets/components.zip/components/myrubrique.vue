<template>
    <div>
        {{rubrique}}
        <div class="form-group">
<!--            <select class="form-control" v-model="id" @input="$emit('blur', qui)" v-on:change="categories_get">-->
<!--            <select class="form-control" v-model="id" @change="$emit('blur', id)" @click="handleClick">-->
            <select class="form-control" v-model="id" @change="handleInput(id)" @blur="handleClick">
                <option></option>
                <option v-for="item in rubriques_list" :value="item.id">{{item.name}}</option>
            </select>
        </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            id: 0,
            categories_list: '',
            rubriques_list: '',
            rubrique: ''
        }
    },
    created: function () {
        this.type_rubrique();
    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value);
            this.$emit('click');
        },
        handleClick () {
            this.$emit('click');
        },
        type_rubrique () {
            getWithParams('/admin/typerubrique').then(data => {
                this.rubriques_list = data;
                console.log(this.rubriques_list);
            });
        }
    }
}
</script>

<style scoped>

</style>
