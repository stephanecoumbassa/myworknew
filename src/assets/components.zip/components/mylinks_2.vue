<template>
    <div>
        <div class="row">
            <div v-if="links_list.length >=1" v-for="item in links_list" class="col-3">
                <div class="card">
                    <div class="card-body">
                        {{item.name}}<br>
                        {{item.type}}
                    </div>
                    <div class="card-footer">
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="links_delete(item)">Supprimer</button>
                        <button type="button" class="btn btn-sm btn-secondary" v-on:click="update(item)">Modifier</button>
                    </div>
                </div>
            </div>
        </div>

        <form @submit.prevent="link_post">
            <div v-for="item in links" v-if="links.length >=1">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-member-item">Type de lien</label>
                            <select v-validate="'required'" required class="form-control" v-model="item.type" @input="$emit('blur', links)">
                                <option></option>
                                <option v-for="item in links_type_list"
                                        :value="item.id"
                                        :key="item.id">
                                    {{item.name}}
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-member-item">Lien</label>
                            <input v-validate="'required|url'" required class="form-control" type="url" v-model="item.name" />
                        </div>
                    </div>
                </div>
                <input v-if="update_status" class="btn btn-primary" type="button" name="submit" value="modifier" v-on:click="link_update(item)">
                <br>
            </div>

            <button v-if="!update_status" type="button" class="btn btn-secondary btn-sm" v-on:click="link_delete">-</button>
            <button v-if="!update_status" type="button" class="btn btn-secondary btn-sm" v-on:click="link_add">+</button>
            <button v-if="!update_status" type="submit" class="btn btn-primary btn-sm">Ajouter</button>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            update_status: false,
            links: [{}],
            links_type_list: [],
            links_list: []
        }
    },
    created: function () {
        this.links_get();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.link_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        links_get () {
            getWithParams('/api/get/links_type').then((data) => {
                this.links_type_list = data;
            })
        },
        link_get () {
            getWithParams('/api/get/links', { idligne: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                this.links_list = JSON.parse(data.links);
                console.log(this.links);
            })
        },
        link_post () {
            postWithParams('/api/post/links', { links: this.links, id: this.idligne, typerubrique: this.typerubrique })
                .then((data) => {
                    this.links = [{}];
                    this.link_get();
                });
        },
        link_update (link) {
            if (confirm('Voulez vous modifier ?')) { this.update_status = false; }
            putWithParams('/api/put/links', link).then((data) => {
                console.log(data);
                this.links = [{}];
                this.link_get();
            });
        },
        links_delete (link) {
            console.log(link.id);
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/links', { data: { id: link.id } }).then((data) => {
                    console.log(data);
                    this.links = [{}];
                    this.link_get();
                });
            }
        },
        update (link) {
            link.type = link.typeid;
            this.links = [link];
            this.update_status = true;
            console.log(this.links);
        },
        link_add () {
            this.links.push({});
        },
        link_delete () {
            this.links.pop();
        }
    }
}
</script>

<style scoped>

</style>
