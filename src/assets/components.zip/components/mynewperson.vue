<template>
    <div>
        <button type="button" class="btn btn-sm btn-secondary" v-on:click="show">Nouvelle Personne</button><br>
        <form v-if="add">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Nom</label>
                            <input v-model="newperson.name" class="form-control" type="text">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Prenoms</label>
                            <input  v-model="newperson.firstname" class="form-control" type="text">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Email</label>
                            <input  v-model="newperson.email" class="form-control" type="email">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Telephone</label>
                            <input  v-model="newperson.telephone" class="form-control" type="text">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">CNI</label>
                            <input  v-model="newperson.cni" class="form-control" type="text">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Id Qui est Qui ?</label>
                            <v-select  v-model="newperson.qui" label="fullname" :options="autocomplete_list2" />
                        </div>
                    </div>
                    <div class="col-6">
                        <div v-if="!image">
                            <h6>Selectionner une image</h6>
                            <!--                            <input  v-validate="'size:1000'" name="img" type="file" @change="onFileChange">-->
                            <input  v-validate="'size:1000'" name="img" type="file" @change="onFileChange">
                        </div>
                        <div v-else>
                            <!--        {{image}}-->
                            <img style="width: 100%" :src="image"/>
                            <button @click="removeImage">supprimer l'image</button>
                        </div>
                    </div>
<!--                </div>-->
            </div>
            <button v-on:click="person_add_one" class="btn btn-primary" type="button">Ajouter</button>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            autocomplete_list: [],
            autocomplete_list2: [],
            autocomplete_initiales: '',
            count: 0,
            newperson: { qui: { id: null } },
            newpersons: [{}],
            qui: [],
            qui2: [],
            qui_list: '',
            person_list: '',
            val: '',
            add: false,
            image: null,
            type: [],
            image_name: '',
            image_extension: ''
        }
    },
    created: function () {
        this.qui_get();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
            // console.log(this.idligne)
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        show () {
            this.add = !this.add
        },
        qui_get () {
            getWithParams('/admin/qui_auto').then(data => {
                const res = JSON.stringify(data);
                this.qui_list = JSON.parse(res);
                this.autocomplete_list2 = this.qui_list;
            });
        },
        person_add_one () {
            this.newperson.qui_id = this.newperson.qui.id;
            this.newperson.photo = this.image_name;
            postWithParams('/api/post/persons_one',
                           { valjson: JSON.stringify(this.newperson),
                             id: this.idligne,
                             image: this.image,
                             image_name: this.image_name,
                             image_extension: this.image_extension }).then((data) => {
                                 console.log(data);
                             });
        },
        onFileChange (e) {
            console.log(e);
            var files = e.target.files || e.dataTransfer.files;
            if (!files.length) { return; }
            this.createImage(files[0]);
        },
        createImage (file) {
            console.log(file);
            var a = file.name.split('.');
            this.image_name = file.name;
            this.image_extension = a[1];

            var image = new Image();
            var reader = new FileReader();
            var vm = this;

            reader.onload = (e) => {
                vm.image = e.target.result;
                this.handleInput(vm.image)
            };
            reader.readAsDataURL(file);
        },
        removeImage: function (e) {
            this.image = '';
        },
        reset () {
            this.image = null;
            this.image_name = '';
            this.image_extension = '';
        }

    }
}
</script>

<style scoped>

</style>
