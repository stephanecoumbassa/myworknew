<template>
    <div>
        <form>
            <div v-for="item in tags">
                <div class="row">
                    <div class="col-8">
                        <div class="form-group">
                            <label class="form-text text-dark">Mots Cles</label>
                            <input class="form-control" type="url" v-model="item.name" />
                        </div>
                    </div>
                    <div class="col-4">
                        <label class="form-text text-dark">Actions</label>
                        <button type="button" class="btn btn-secondary btn-sm" v-on:click="tag_delete(item)">supprimer</button>
                        <button type="button" class="btn btn-primary btn-sm" v-on:click="tag_update(item)">modifier</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            tags: {},
            country: '',
            tags_list: ''
        }
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    mounted: function () {

    },
    watch: {
        idligne: {
            // the callback will be called immediately after the start of the observation
            immediate: true,
            handler (val, oldVal) {
                this.tag_get();
            }
        }
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        tag_get () {
            getWithParams('/api/get/tags', { id: this.idligne, typerubrique: this.typerubrique }).then((data) => {
                console.log(data);
                this.tags = JSON.parse(data.tags);
            })
        },
        tag_update (tag) {
            putWithParams('/api/put/tags', tag).then((data) => {
                console.log(data);
            });
        },
        tag_delete (tag) {
            console.log(tag.id);
            deleteWithParams('/api/delete/tags', { data: { id: tag.id } }).then((data) => {
                console.log(data);
            });
        }
    }
}
</script>

<style scoped>

</style>
