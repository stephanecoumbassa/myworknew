<template>
  <div>
    <form @submit.prevent="promotion_add()">
      <div v-for="item in sections">
        <div class="row">
          <div class="col-4">
            <div class="form-group">
              <label class="form-text text-dark">Nom de la section</label>
              <input required class="form-control" v-model="item.name" @input="$emit('blur', sections)" />
            </div>
          </div>
          <div class="col-8">
            <div class="form-group">
              <label class="form-text text-dark">Description de la section</label>
              <textarea class="form-group" v-model="item.description"></textarea>
            </div>
          </div>
        </div>
      </div>

      <button type="button" class="btn btn-primary btn-sm" v-on:click="section_create">Ajouter les sections</button>

      <button type="button" class="btn btn-secondary btn-sm" v-on:click="section_delete">-</button>
      <button type="button" class="btn btn-primary btn-sm" v-on:click="section_add">+</button>
    </form>
  </div>
</template>

<script>
module.exports = {
  data: function () {
    return {
      count: 0,
      item: [],
      sections: [],
      sections_list: ''
    }
  },
  props: {
    idligne: Number
  },
  created: function () {

  },
  model: {
    event: 'blur'
  },
  methods: {
    handleInput (value) {
      this.$emit('blur', value)
    },
    section_create () {
      postWithParams('/api/post/sections', { valjson: JSON.stringify(this.sections), id: this.idligne }).then(data => {
        console.log(data)
      });
    },
    section_add () {
      this.sections.push({ 'type': null, 'name': null });
    },
    section_delete () {
      this.sections.pop();
    }
  }
}
</script>

<style scoped>

</style>
