<template>
    <div>
        <button  v-on:click="show()" type="button" class="btn btn-secondary">Montrer/Cacher les dirigeants</button>
        <div v-for="person in qui" class="">
            <form v-if="add">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Dirigeants</label>
                            <v-select  v-model="person.id" label="fullname" :options="autocomplete_list2" />
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Date debut</label>
                            <input  v-model="person.date_start" class="form-control" type="date">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Date Fin</label>
                            <input  v-model="person.date_end" class="form-control" type="date">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Fonction</label>
                            <input v-model="person.fonction" class="form-control" type="text">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-text text-dark">Ordre</label>
                            <input  v-model="person.ordre" class="form-control" type="number">
                        </div>
                    </div>
                    <div class="col-6">
                        <img style="width: 40%"
                             :src="'http://localhost:8888/cms_frontend/public/assets/uploads/personnes/'+person.photo"/>
                    </div>
                </div>
                <button v-on:click="person_delete(person.id)" class="btn btn-secondary" type="button">Supprimer de cette liste</button>
                <button v-on:click="person_update(person)" class="btn btn-primary" type="button">Modifier</button>
            </form>
        </div>

    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            autocomplete_list: [],
            autocomplete_list2: [],
            autocomplete_initiales: '',
            count: 0,
            newperson: { qui: { id: null } },
            newpersons: [{}],
            qui: [{}],
            qui2: [],
            qui_list: '',
            person_list: [],
            persons_list: [],
            val: '',
            add: false,
            image: null,
            type: [],
            image_name: '',
            image_extension: ''
        }
    },
    created: function () {
        this.qui_get();
    },
    model: {
        event: 'blur'
    },
    props: {
        idligne: Number,
        typerubrique: Number
    },
    watch: {
        idligne: {
            immediate: true,
            handler (val, oldVal) {
                this.person_get_by_compagny();
            }
        }
    },
    methods: {
        handleInput (value) {
            // this.$emit('blur', value)
        },
        show () {
            this.add = !this.add
        },
        person_get_by_compagny () {
            getWithParams('/api/get/persons_company', { id: this.idligne }).then(data => {
                console.log(data);
                this.qui = data;
                console.log(this.qui);
            });
        },
        qui_get () {
            getWithParams('/api/get/persons').then(data => {
                const res = JSON.stringify(data);
                this.qui_list = JSON.parse(res);
                this.autocomplete_list2 = this.qui_list;
            });
        },

        person_delete (id) {
            if (confirm('Voulez vous supprimer ?')) {
                deleteWithParams('/api/delete/persons/' + id).then((data) => {
                    console.log(data);
                }, (error) => {
                    console.log(error)
                });
            }
        },
        person_update (person) {
            if (confirm('Voulez vous modifier ?')) {
                putWithParams('/api/put/persons_one',
                              { valjson: JSON.stringify(person), id: this.idligne }).then((data) => {
                                  console.log(data);
                              }, (error) => {
                                  console.log(error)
                              });
            }
        }

    }
}
</script>

<style scoped>

</style>
