Vue.component('myscategories', {
    delimiters: ['${', '}'],
    props: {
        typerubrique: Number
    },
    data: function () {
        return {
            count: 0,
            categories_list: '',
            categories_master_list: '',
            categories: '',
            scategories: null
        }
    },
    created: function () {
        this.categories_get();
    },
    methods: {
        categories_get () {
            getWithParams('/admin/categories', { id: this.typerubrique }).then(data => {
                const res = JSON.stringify(data);
                this.categories_list = JSON.parse(res);
                console.log(this.categories_list);
            });
        }
    },
    template: ' <div v-if="scategories !== null" class="form-group">\
                    <label class="form-text text-dark">Categories</label>\
                    <select class="form-control search-slt" v-model="scategories" name="catid">\
                        <option></option>\
                        <option v-for="scat in categories_list"\
                                >${scat.name}</option>\
                    </select>\
                </div>\
            '
});
