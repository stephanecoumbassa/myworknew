Vue.component('myaddress', {
    delimiters: ['${', '}'],
    data: function () {
        return {
            count: 0,
            addresses: [{ 'country_id': null, 'city_id': null, 'quartier_id': null, 'longlat': null, 'description': null }]

        }
    },
    methods: {
       address_add () {
           this.addresses.push({ 'country_id': null, 'city_id': null, 'longlat': null, 'description': null });
       },
       address_delete () {
           this.addresses.pop();
       }
    },
    template: ' <div> \
                     <div v-for="address in addresses">\
                     <div class="form-group">\
                         <label class="form-text text-dark">Country</label>\
                         <select class="form-control search-slt" v-model="address.country_id">\
                             <option value="1">RCI</option>\
                             <option value="2">Mali</option>\
                             <option value="2">Senegal</option>\
                         </select>\
                     </div>\
                     <div class="form-group">\
                         <label class="form-text text-dark">City_id</label>\
                         <select class="form-control search-slt" v-model="address.country_id">\
                             <option value="1">Abidjan</option>\
                             <option value="2">Mali</option>\
                             <option value="2">Senegal</option>\
                         </select>\
                     </div>\
                     <div class="form-group">\
                         <label class="form-text text-dark">Quartier_id</label>\
                         <select class="form-control search-slt" v-model="address.quartier_id">\
                             <option value="1">RCI</option>\
                             <option value="2">Mali</option>\
                             <option value="2">Senegal</option>\
                         </select>\
                     </div>\
                     <div class="form-group">\
                         <label class="form-text text-dark">description_id</label>\
                         <input class="form-control" type="text" v-model="address.longlat" />\
                     </div>\
                     <div class="form-group">\
                         <label class="form-text text-dark">description_id</label>\
                         <textarea class="form-control" v-model="address.description"></textarea>\
                     </div>\
                 </div>\
                 <button type="button" class="btn btn-secondary btn-sm" v-on:click="address_delete">-</button>\
                 <button type="button" class="btn btn-primary btn-sm" v-on:click="address_add">+</button>  \
               </div>\
            '
});
