<template>
    <div>
            <div class="row">
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Capacite</label>
                        <input class="form-control" name=""  v-model="capacity"/>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <label class="form-text text-dark">Unité</label>
                        <input class="form-control" name=""  v-model="unity"/>
                    </div>
                </div>
                <div class="col-4">
                    <label class="form-text text-dark">.</label>
                    <button type="button" class="btn btn-primary" v-on:click="capacities_create">Creer une specialite</button>
                </div>
            </div>
    </div>
</template>

<script>
module.exports = {
    data: function () {
        return {
            count: 0,
            item: [],
            capacity: '',
            unity: '',
            speciality: ''
        }
    },
    created: function () {

    },
    model: {
        event: 'blur'
    },
    methods: {
        handleInput (value) {
            this.$emit('blur', value)
        },
        capacities_create () {
            postWithParams('/api/post/capacities_type', { name: this.speciality, unity: this.unity }).then(data => {
                const res = JSON.stringify(data);
                console.log(res);
            // console.log(this.specialities_list);
            });
        }
    }
}
</script>

<style scoped>

</style>
